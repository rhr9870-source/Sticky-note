# IdeaPad Security Specification (Phase 0 TDD)

## 1. Data Invariants
1. **Strict User Isolation**: Every note (`/users/{userId}/notes/{noteId}`) and preference document (`/users/{userId}/settings/{settingId}`) belongs exclusively to `userId` and can only be read, listed, created, updated, or deleted when `request.auth != null && request.auth.uid == userId`.
2. **Immutable Ownership & Creation Metadata**: `userId` and `createdAt` cannot be modified after creation (`incoming().userId == existing().userId && incoming().createdAt == existing().createdAt`).
3. **Temporal Integrity**: `createdAt` and `updatedAt` must be server timestamps (`is timestamp && <= request.time`).
4. **Schema & Size Bounds**: Every string and list is strictly bounded in length/size, enums are validated against allowlists, and no ghost fields are allowed (`hasOnly`).

## 2. The "Dirty Dozen" Payloads
1. **Unauthenticated Read**: `unauthDb.doc("users/alice_123/notes/note_1").get()` -> Reject
2. **Cross-User Read**: Bob reading `users/alice_123/notes/note_1` -> Reject
3. **Identity Spoofing on Create**: Alice creating `users/alice_123/notes/note_1` with `userId: "bob_456"` -> Reject
4. **Shadow/Ghost Field Injection**: Adding `isAdmin: true` to note payload -> Reject (`hasOnly`)
5. **Title/Content Oversize (Denial of Wallet)**: `title` > 200 chars or `content` > 5000 chars -> Reject
6. **Invalid Status Enum**: `status: "hacked"` instead of `['active', 'completed', 'archived', 'trashed']` -> Reject
7. **Invalid Note Color Enum**: `colorTheme: "neon"` instead of allowed palette -> Reject
8. **Unbounded Tags Array**: `tags` with > 10 elements -> Reject
9. **Immutable `createdAt` Mutation**: Updating `createdAt` on an existing note -> Reject
10. **Immutable `userId` Mutation**: Updating `userId` on an existing note -> Reject
11. **Future Timestamp Spoofing**: `createdAt` in the future (`> request.time`) -> Reject
12. **PII / Preferences Cross-User Access**: Bob reading or updating `users/alice_123/settings/preferences` -> Reject
