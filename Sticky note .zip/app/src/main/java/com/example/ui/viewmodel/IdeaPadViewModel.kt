package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.IdeaNote
import com.example.data.model.IdeaPadAssets
import com.example.data.model.UserPreferences
import com.example.data.repository.IdeaPadRepository
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Success<T>(val data: T) : UiState<T>
    data class Error(val message: String) : UiState<Nothing>
}

enum class TopDestination {
    WORKSPACE,
    COMPLETED,
    SETTINGS
}

enum class WorkspaceSubTab {
    BOARD,
    ARCHIVE,
    TRASH
}

enum class WorkspaceLayoutMode {
    MASONRY,
    INFINITE_CANVAS
}

enum class CompletedSortOrder(val label: String) {
    RECENT("SORT BY: RECENT"),
    TITLE("SORT BY: TITLE"),
    COLOR("SORT BY: COLOR")
}

class IdeaPadViewModel(
    private val repository: IdeaPadRepository,
    private val currentUserId: String,
    initialUserName: String = "Creative Thinker",
    initialUserEmail: String = "hello@ideapad.app",
    val isGuestMode: Boolean = false
) : ViewModel() {

    private val _guestNotes = MutableStateFlow<List<IdeaNote>>(
        if (isGuestMode) IdeaPadAssets.buildInitialNotes(currentUserId) else emptyList()
    )
    private val _guestPreferences = MutableStateFlow(
        UserPreferences(
            userId = currentUserId,
            displayName = initialUserName.ifBlank { if (isGuestMode) "Guest Creative" else "Creative Thinker" },
            email = initialUserEmail.ifBlank { if (isGuestMode) "guest@ideapad.local" else "hello@ideapad.app" }
        )
    )

    val notesState: StateFlow<UiState<List<IdeaNote>>> = if (isGuestMode) {
        _guestNotes.map<List<IdeaNote>, UiState<List<IdeaNote>>> { UiState.Success(it) }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Success(_guestNotes.value)
            )
    } else {
        repository.observeNotes(currentUserId)
            .map<List<IdeaNote>, UiState<List<IdeaNote>>> { UiState.Success(it) }
            .catch { error ->
                Log.w(TAG, "Error observing notes", error)
                emit(UiState.Error(error.message ?: "Failed to observe notes"))
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UiState.Loading
            )
    }

    val preferencesState: StateFlow<UserPreferences> = if (isGuestMode) {
        _guestPreferences.asStateFlow()
    } else {
        repository.observePreferences(currentUserId)
            .map { prefs ->
                prefs ?: UserPreferences(
                    userId = currentUserId,
                    displayName = initialUserName.ifBlank { "Creative Thinker" },
                    email = initialUserEmail.ifBlank { "hello@ideapad.app" }
                )
            }
            .catch { error ->
                Log.w(TAG, "Error observing preferences", error)
                emit(
                    UserPreferences(
                        userId = currentUserId,
                        displayName = initialUserName.ifBlank { "Creative Thinker" },
                        email = initialUserEmail.ifBlank { "hello@ideapad.app" }
                    )
                )
            }
            .stateIn(
                scope = viewModelScope,
                started = SharingStarted.WhileSubscribed(5000L),
                initialValue = UserPreferences(
                    userId = currentUserId,
                    displayName = initialUserName.ifBlank { "Creative Thinker" },
                    email = initialUserEmail.ifBlank { "hello@ideapad.app" }
                )
            )
    }

    private val _currentDestination = MutableStateFlow(TopDestination.WORKSPACE)
    val currentDestination: StateFlow<TopDestination> = _currentDestination.asStateFlow()

    private val _workspaceSubTab = MutableStateFlow(WorkspaceSubTab.BOARD)
    val workspaceSubTab: StateFlow<WorkspaceSubTab> = _workspaceSubTab.asStateFlow()

    private val _layoutMode = MutableStateFlow(WorkspaceLayoutMode.MASONRY)
    val layoutMode: StateFlow<WorkspaceLayoutMode> = _layoutMode.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _completedSortOrder = MutableStateFlow(CompletedSortOrder.RECENT)
    val completedSortOrder: StateFlow<CompletedSortOrder> = _completedSortOrder.asStateFlow()

    private val _statusBannerMessage = MutableStateFlow<String?>(null)
    val statusBannerMessage: StateFlow<String?> = _statusBannerMessage.asStateFlow()

    init {
        if (!isGuestMode) {
            viewModelScope.launch {
                repository.seedInitialWorkspaceIfEmpty(
                    defaultDisplayName = initialUserName,
                    defaultEmail = initialUserEmail
                ).onFailure { error ->
                    Log.w(TAG, "seedInitialWorkspace note: ${error.localizedMessage}")
                }
            }
        }
    }

    fun selectDestination(destination: TopDestination) {
        _currentDestination.value = destination
    }

    fun selectWorkspaceSubTab(subTab: WorkspaceSubTab) {
        _workspaceSubTab.value = subTab
        _currentDestination.value = TopDestination.WORKSPACE
    }

    fun toggleWorkspaceLayoutMode() {
        _layoutMode.value = if (_layoutMode.value == WorkspaceLayoutMode.MASONRY) {
            WorkspaceLayoutMode.INFINITE_CANVAS
        } else {
            WorkspaceLayoutMode.MASONRY
        }
    }

    fun setWorkspaceLayoutMode(mode: WorkspaceLayoutMode) {
        _layoutMode.value = mode
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun cycleCompletedSortOrder() {
        val values = CompletedSortOrder.entries
        val nextIndex = (values.indexOf(_completedSortOrder.value) + 1) % values.size
        _completedSortOrder.value = values[nextIndex]
    }

    fun clearStatusBanner() {
        _statusBannerMessage.value = null
    }

    fun createNote(
        title: String,
        content: String,
        noteType: String,
        colorTheme: String,
        tagsInput: String,
        checklistInput: String,
        imageUrl: String,
        codeSnippet: String
    ) {
        viewModelScope.launch {
            val tags = tagsInput.split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .take(10)
            val checklist = checklistInput.lines()
                .map { it.trim().removePrefix("-").trim() }
                .filter { it.isNotEmpty() }
                .take(20)
            val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.US).format(Date())
            val existingCount = (notesState.value as? UiState.Success)?.data?.size ?: 0
            val offsetX = (80L + (existingCount % 4) * 260L).coerceIn(20L, 2400L)
            val offsetY = (60L + (existingCount / 4) * 220L).coerceIn(20L, 2400L)
            val tilt = when (existingCount % 3) {
                0 -> -1L
                1 -> 1L
                else -> 0L
            }

            val newNote = IdeaNote(
                id = if (isGuestMode) "guest_${System.currentTimeMillis()}_${(100..999).random()}" else "",
                userId = currentUserId,
                title = title.trim().take(200),
                content = content.trim().ifBlank {
                    if (checklist.isNotEmpty()) checklist.joinToString("\n") else "New sticky thought"
                }.take(5000),
                noteType = noteType,
                colorTheme = colorTheme,
                status = "active",
                tags = tags,
                checklistItems = checklist,
                imageUrl = imageUrl.trim().take(1000),
                codeSnippet = codeSnippet.trim().take(2000),
                canvasX = offsetX,
                canvasY = offsetY,
                rotationDeg = tilt,
                dateLabel = dateStr
            )
            if (isGuestMode) {
                _guestNotes.value = listOf(newNote) + _guestNotes.value
                _statusBannerMessage.value = "Added note to Workspace"
            } else {
                repository.createNote(newNote)
                    .onSuccess {
                        _statusBannerMessage.value = "Added note to Workspace"
                    }
                    .onFailure {
                        _statusBannerMessage.value = it.localizedMessage ?: "Could not create note"
                    }
            }
        }
    }

    fun updateExistingNote(
        existing: IdeaNote,
        title: String,
        content: String,
        noteType: String,
        colorTheme: String,
        tagsInput: String,
        checklistInput: String,
        imageUrl: String,
        codeSnippet: String
    ) {
        viewModelScope.launch {
            val tags = tagsInput.split(",")
                .map { it.trim() }
                .filter { it.isNotEmpty() }
                .take(10)
            val checklist = checklistInput.lines()
                .map { it.trim().removePrefix("-").trim() }
                .filter { it.isNotEmpty() }
                .take(20)
            val updated = existing.copy(
                title = title.trim().take(200),
                content = content.trim().take(5000),
                noteType = noteType,
                colorTheme = colorTheme,
                tags = tags,
                checklistItems = checklist,
                imageUrl = imageUrl.trim().take(1000),
                codeSnippet = codeSnippet.trim().take(2000)
            )
            if (isGuestMode) {
                _guestNotes.value = _guestNotes.value.map { if (it.id == updated.id) updated else it }
                _statusBannerMessage.value = "Note updated"
            } else {
                repository.updateNote(updated)
                    .onSuccess {
                        _statusBannerMessage.value = "Note updated"
                    }
            }
        }
    }

    fun updateNoteCanvasPosition(note: IdeaNote, newX: Float, newY: Float) {
        viewModelScope.launch {
            val prefs = preferencesState.value
            val gridStep = when (prefs.gridDensity) {
                1L -> 40f
                3L -> 16f
                else -> 24f
            }
            val finalX = if (prefs.snapToGrid) {
                ((newX / gridStep).roundToLong() * gridStep.toLong()).coerceIn(0L, 4500L)
            } else {
                newX.roundToLong().coerceIn(0L, 4500L)
            }
            val finalY = if (prefs.snapToGrid) {
                ((newY / gridStep).roundToLong() * gridStep.toLong()).coerceIn(0L, 4500L)
            } else {
                newY.roundToLong().coerceIn(0L, 4500L)
            }
            val updated = note.copy(canvasX = finalX, canvasY = finalY)
            if (isGuestMode) {
                _guestNotes.value = _guestNotes.value.map { if (it.id == updated.id) updated else it }
            } else {
                repository.updateNote(updated)
            }
        }
    }

    fun updateNoteStatus(note: IdeaNote, newStatus: String) {
        viewModelScope.launch {
            val dateStr = SimpleDateFormat("MMM dd, yyyy", Locale.US).format(Date())
            val updated = note.copy(status = newStatus, dateLabel = dateStr)
            val label = when (newStatus) {
                "completed" -> "Marked as Done & Dusted"
                "archived" -> "Moved to Archive"
                "trashed" -> "Moved to Trash"
                else -> "Restored to Workspace"
            }
            if (isGuestMode) {
                _guestNotes.value = _guestNotes.value.map { if (it.id == updated.id) updated else it }
                _statusBannerMessage.value = label
            } else {
                repository.updateNote(updated)
                    .onSuccess {
                        _statusBannerMessage.value = label
                    }
            }
        }
    }

    fun deleteNoteForever(noteId: String) {
        viewModelScope.launch {
            if (isGuestMode) {
                _guestNotes.value = _guestNotes.value.filterNot { it.id == noteId }
                _statusBannerMessage.value = "Note deleted permanently"
            } else {
                repository.deleteNote(noteId)
                    .onSuccess {
                        _statusBannerMessage.value = "Note deleted permanently"
                    }
            }
        }
    }

    fun clearAllByStatus(status: String) {
        viewModelScope.launch {
            val label = if (status == "completed") {
                "Cleared all completed notes"
            } else {
                "Emptied Trash"
            }
            if (isGuestMode) {
                _guestNotes.value = _guestNotes.value.filterNot { it.status == status }
                _statusBannerMessage.value = label
            } else {
                repository.clearNotesByStatus(status)
                    .onSuccess {
                        _statusBannerMessage.value = label
                    }
            }
        }
    }

    fun updatePreferences(transform: (UserPreferences) -> UserPreferences) {
        viewModelScope.launch {
            val updated = transform(preferencesState.value)
            if (isGuestMode) {
                _guestPreferences.value = updated
            } else {
                repository.savePreferences(updated)
            }
        }
    }

    fun syncNow() {
        viewModelScope.launch {
            val timeStr = SimpleDateFormat("h:mm a", Locale.US).format(Date())
            val updated = preferencesState.value.copy(
                lastSyncedLabel = "Just now ($timeStr)"
            )
            if (isGuestMode) {
                _guestPreferences.value = updated
                _statusBannerMessage.value = "Guest Mode: Sign in to sync across devices"
            } else {
                repository.savePreferences(updated)
                    .onSuccess {
                        _statusBannerMessage.value = "All systems synced to Cloud"
                    }
            }
        }
    }

    fun restoreStarterWorkspace() {
        viewModelScope.launch {
            if (isGuestMode) {
                _guestNotes.value = IdeaPadAssets.buildInitialNotes(currentUserId)
                _statusBannerMessage.value = "Starter IdeaPad notes restored"
            } else {
                repository.resetToStarterNotes()
                    .onSuccess {
                        _statusBannerMessage.value = "Starter IdeaPad notes restored"
                    }
            }
        }
    }

    private companion object {
        const val TAG = "IdeaPadVM"
    }
}
