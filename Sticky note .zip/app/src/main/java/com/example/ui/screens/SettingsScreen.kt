package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.IdeaNote
import com.example.data.model.IdeaPadAssets
import com.example.data.model.UserPreferences
import com.example.ui.theme.BricolageFontFamily
import com.example.ui.theme.NoteGreenActive
import com.example.ui.theme.NoteGreenText
import com.example.ui.theme.NoteNeutralCode
import com.example.ui.theme.NotePinkActive
import com.example.ui.theme.NotePinkText
import com.example.ui.theme.NoteYellowActive
import com.example.ui.theme.NoteYellowText
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.SpaceMonoFontFamily
import kotlin.math.roundToLong

@Composable
fun SettingsScreen(
    preferences: UserPreferences,
    allNotes: List<IdeaNote>,
    isExpandedScreen: Boolean,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit,
    onSyncNow: () -> Unit,
    onRestoreStarterNotes: () -> Unit,
    onSignOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showProfileDialog by remember { mutableStateOf(false) }
    var showNoteStyleSheet by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var showHelpDialog by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = if (isExpandedScreen) 1040.dp else 680.dp)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(
                    start = if (isExpandedScreen) 32.dp else 16.dp,
                    end = if (isExpandedScreen) 32.dp else 16.dp,
                    top = 12.dp,
                    bottom = 112.dp
                ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            Column(modifier = Modifier.padding(bottom = 6.dp)) {
                Text(
                    text = "Settings",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = if (isExpandedScreen) 36.sp else 26.sp,
                    lineHeight = if (isExpandedScreen) 44.sp else 32.sp,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (isExpandedScreen) {
                        "Customize your digital desktop experience."
                    } else {
                        "Manage your digital desktop preferences."
                    },
                    fontFamily = QuicksandFontFamily,
                    fontSize = if (isExpandedScreen) 16.sp else 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (isExpandedScreen) {
                // Desktop / Tablet 2-Column Settings Layout (matching Image 6)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        ExpandedProfileCard(
                            preferences = preferences,
                            onEditProfile = { showProfileDialog = true }
                        )
                        ExpandedDefaultNoteStyleCard(
                            preferences = preferences,
                            onUpdatePreferences = onUpdatePreferences
                        )
                    }
                    Column(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        ExpandedAppearanceCard(
                            preferences = preferences,
                            onUpdatePreferences = onUpdatePreferences
                        )
                        ExpandedCanvasSettingsCard(
                            preferences = preferences,
                            onUpdatePreferences = onUpdatePreferences
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                ExpandedSyncAndBackupCard(
                    preferences = preferences,
                    onExport = { showExportDialog = true },
                    onSyncNow = onSyncNow
                )
            } else {
                // Mobile Settings Card Stack (matching Image 1 + interactive expansions)
                MobileProfileCard(
                    preferences = preferences,
                    onClick = { showProfileDialog = true }
                )

                MobileAppearanceCard(
                    preferences = preferences,
                    onUpdatePreferences = onUpdatePreferences
                )

                MobileDefaultNoteStyleCard(
                    preferences = preferences,
                    onClick = { showNoteStyleSheet = true }
                )

                MobileCanvasGridCard(
                    preferences = preferences,
                    onUpdatePreferences = onUpdatePreferences
                )

                MobileSyncAndBackupCard(
                    preferences = preferences,
                    onSyncNow = onSyncNow,
                    onExport = { showExportDialog = true }
                )

                MobileHelpAndSupportCard(
                    onClick = { showHelpDialog = true }
                )
            }

            // Footer: IdeaPad v2.4.1 & Sign Out (from Image 1)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 18.dp, bottom = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "IdeaPad v2.4.1",
                    fontFamily = QuicksandFontFamily,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val isGuest = preferences.userId == "guest_user" || preferences.email == "guest@ideapad.local"
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = if (isGuest) "Exit Guest / Sign In with Google" else "Sign Out",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 0.5.sp,
                    color = if (isGuest) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onSignOut() }
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                        .testTag("sign_out_button")
                )
            }
        }
    }

    if (showProfileDialog) {
        ProfileEditDialog(
            preferences = preferences,
            onDismiss = { showProfileDialog = false },
            onSave = { newName, newEmail ->
                onUpdatePreferences { it.copy(displayName = newName, email = newEmail) }
                showProfileDialog = false
            }
        )
    }

    if (showNoteStyleSheet) {
        DefaultNoteStyleDialog(
            preferences = preferences,
            onDismiss = { showNoteStyleSheet = false },
            onUpdatePreferences = onUpdatePreferences
        )
    }

    if (showExportDialog) {
        ExportWorkspaceDialog(
            notes = allNotes,
            onDismiss = { showExportDialog = false },
            onRestoreStarter = {
                onRestoreStarterNotes()
                showExportDialog = false
            }
        )
    }

    if (showHelpDialog) {
        HelpSupportDialog(onDismiss = { showHelpDialog = false })
    }
}

@Composable
private fun MobileProfileCard(
    preferences: UserPreferences,
    onClick: () -> Unit
) {
    val initials = remember(preferences.displayName) {
        val parts = preferences.displayName.trim().split(" ").filter { it.isNotEmpty() }
        if (parts.size >= 2) {
            "${parts[0].first()}${parts[1].first()}".uppercase()
        } else {
            "US"
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("settings_profile_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = CircleShape,
                    color = NoteYellowActive,
                    modifier = Modifier.size(48.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = if (preferences.displayName == "Creative Thinker") "US" else initials,
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 20.sp,
                            color = NoteYellowText
                        )
                    }
                }
                Column {
                    Text(
                        text = "Profile",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Manage your account details and subscription.",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = "Open Profile",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MobileAppearanceCard(
    preferences: UserPreferences,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("settings_appearance_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = NoteYellowActive.copy(alpha = 0.35f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Palette,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Text(
                    text = "Appearance",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 20.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            // Segmented Light / Dark / Auto control matching Image 1
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceContainerHigh,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    val modes = listOf(
                        Triple("light", "Light", Icons.Filled.LightMode),
                        Triple("dark", "Dark", Icons.Filled.DarkMode),
                        Triple("auto", "Auto", Icons.Filled.BrightnessAuto)
                    )
                    modes.forEach { (key, label, icon) ->
                        val selected = preferences.themeMode == key
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (selected) {
                                MaterialTheme.colorScheme.surfaceContainerLowest
                            } else {
                                Color.Transparent
                            },
                            shadowElevation = if (selected) 2.dp else 0.dp,
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable {
                                    onUpdatePreferences { it.copy(themeMode = key) }
                                }
                                .testTag("theme_mode_$key")
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = null,
                                    tint = if (selected) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = label,
                                    fontFamily = QuicksandFontFamily,
                                    fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                                    fontSize = 14.sp,
                                    color = if (selected) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MobileDefaultNoteStyleCard(
    preferences: UserPreferences,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("settings_default_note_style_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = NotePinkActive.copy(alpha = 0.3f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.Edit,
                            contentDescription = null,
                            tint = NotePinkText,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = "Default Note Style",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Set default color and typography for new notes.",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = "Configure Default Note Style",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun MobileCanvasGridCard(
    preferences: UserPreferences,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("settings_canvas_grid_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = NoteGreenActive.copy(alpha = 0.35f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.GridView,
                            contentDescription = null,
                            tint = NoteGreenText,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Column(modifier = Modifier.padding(end = 8.dp)) {
                    Text(
                        text = "Canvas Grid",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Adjust snapping, spacing, and masonry behavior.",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Switch(
                checked = preferences.canvasGridEnabled,
                onCheckedChange = { enabled ->
                    onUpdatePreferences { it.copy(canvasGridEnabled = enabled) }
                },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = NoteYellowText,
                    checkedTrackColor = NoteYellowActive
                ),
                modifier = Modifier.testTag("canvas_grid_switch")
            )
        }
    }
}

@Composable
private fun MobileSyncAndBackupCard(
    preferences: UserPreferences,
    onSyncNow: () -> Unit,
    onExport: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSyncNow() }
            .testTag("settings_sync_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = NoteYellowActive.copy(alpha = 0.35f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Filled.CloudSync,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = "Sync & Backup",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Last synced: ${preferences.lastSyncedLabel}",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Icon(
                imageVector = Icons.Filled.ChevronRight,
                contentDescription = "Sync or Export",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.clickable { onExport() }
            )
        }
    }
}

@Composable
private fun MobileHelpAndSupportCard(
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("settings_help_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLow
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                    modifier = Modifier.size(40.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.HelpOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
                Column {
                    Text(
                        text = "Help & Support",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 20.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Guides, FAQs, and contact.",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                contentDescription = "Open Help",
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

// --- Expanded Desktop / Tablet Cards (Matching Image 6) ---

@Composable
private fun ExpandedProfileCard(
    preferences: UserPreferences,
    onEditProfile: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Person,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Profile",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 22.sp
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            )
            Row(
                horizontalArrangement = Arrangement.spacedBy(20.dp),
                verticalAlignment = Alignment.Top
            ) {
                AsyncImage(
                    model = IdeaPadAssets.PROFILE_AVATAR_IMAGE,
                    contentDescription = "Profile Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .border(2.dp, MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                        .clickable { onEditProfile() }
                )
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column {
                        Text(
                            text = "Display Name",
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onEditProfile() }
                        ) {
                            Text(
                                text = preferences.displayName,
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 16.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                    }
                    Column {
                        Text(
                            text = "Email",
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surfaceContainerLow,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onEditProfile() }
                        ) {
                            Text(
                                text = preferences.email,
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Medium,
                                fontSize = 16.sp,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ExpandedAppearanceCard(
    preferences: UserPreferences,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Palette,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Appearance",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 22.sp
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            )
            Text(
                text = "Theme",
                fontFamily = QuicksandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                val modes = listOf(
                    Triple("light", "Light", Icons.Filled.LightMode),
                    Triple("dark", "Dark", Icons.Filled.DarkMode),
                    Triple("auto", "Auto", Icons.Filled.BrightnessAuto)
                )
                modes.forEach { (key, label, icon) ->
                    val selected = preferences.themeMode == key
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) NoteYellowActive else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (selected) BorderStroke(2.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onUpdatePreferences { it.copy(themeMode = key) } }
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = icon,
                                contentDescription = null,
                                tint = if (selected) NoteYellowText else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = label,
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp,
                                color = if (selected) NoteYellowText else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Reduce Motion",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "Minimize animations on canvas",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = preferences.reduceMotion,
                    onCheckedChange = { checked ->
                        onUpdatePreferences { it.copy(reduceMotion = checked) }
                    }
                )
            }
        }
    }
}

@Composable
private fun ExpandedDefaultNoteStyleCard(
    preferences: UserPreferences,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit
) {
    var fontMenuExpanded by remember { mutableStateOf(false) }
    val fontLabel = when (preferences.defaultTypography) {
        "quicksand" -> "Quicksand"
        "mono" -> "Space Mono"
        else -> "Bricolage Grotesque"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Edit,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Default Note Style",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 22.sp
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            )
            Text(
                text = "Default Color",
                fontFamily = QuicksandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                val swatches = listOf(
                    "yellow" to NoteYellowActive,
                    "pink" to NotePinkActive,
                    "green" to NoteGreenActive,
                    "neutral" to NoteNeutralCode
                )
                swatches.forEach { (key, color) ->
                    val selected = preferences.defaultNoteColor == key
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (selected) 2.5.dp else 0.dp,
                                color = if (selected) MaterialTheme.colorScheme.primary else Color.Transparent,
                                shape = CircleShape
                            )
                            .clickable {
                                onUpdatePreferences { it.copy(defaultNoteColor = key) }
                            }
                    )
                }
            }
            Spacer(modifier = Modifier.height(18.dp))
            Text(
                text = "Typography",
                fontFamily = QuicksandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Box {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceContainerLow,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { fontMenuExpanded = true }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = fontLabel,
                            fontFamily = when (preferences.defaultTypography) {
                                "quicksand" -> QuicksandFontFamily
                                "mono" -> SpaceMonoFontFamily
                                else -> BricolageFontFamily
                            },
                            fontSize = 17.sp
                        )
                        Icon(Icons.Filled.ExpandMore, contentDescription = null)
                    }
                }
                DropdownMenu(
                    expanded = fontMenuExpanded,
                    onDismissRequest = { fontMenuExpanded = false }
                ) {
                    DropdownMenuItem(
                        text = { Text("Bricolage Grotesque", fontFamily = BricolageFontFamily) },
                        onClick = {
                            fontMenuExpanded = false
                            onUpdatePreferences { it.copy(defaultTypography = "bricolage") }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Quicksand", fontFamily = QuicksandFontFamily) },
                        onClick = {
                            fontMenuExpanded = false
                            onUpdatePreferences { it.copy(defaultTypography = "quicksand") }
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("Space Mono", fontFamily = SpaceMonoFontFamily) },
                        onClick = {
                            fontMenuExpanded = false
                            onUpdatePreferences { it.copy(defaultTypography = "mono") }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ExpandedCanvasSettingsCard(
    preferences: UserPreferences,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit
) {
    val densityLabel = when (preferences.gridDensity) {
        1L -> "Loose"
        3L -> "Tight"
        else -> "Medium"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.GridView,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Canvas Settings",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 22.sp
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Snap to Grid",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.Medium,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "Align notes automatically",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = preferences.snapToGrid,
                    onCheckedChange = { checked ->
                        onUpdatePreferences { it.copy(snapToGrid = checked) }
                    }
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Grid Density",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = densityLabel,
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Slider(
                value = preferences.gridDensity.toFloat(),
                onValueChange = { v ->
                    onUpdatePreferences { it.copy(gridDensity = v.roundToLong().coerceIn(1L, 3L)) }
                },
                valueRange = 1f..3f,
                steps = 1,
                colors = SliderDefaults.colors(
                    thumbColor = MaterialTheme.colorScheme.primary,
                    activeTrackColor = MaterialTheme.colorScheme.primary
                )
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Loose",
                    fontFamily = QuicksandFontFamily,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Tight",
                    fontFamily = QuicksandFontFamily,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun ExpandedSyncAndBackupCard(
    preferences: UserPreferences,
    onExport: () -> Unit,
    onSyncNow: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerLowest
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(24.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Sync,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Sync & Backup",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 22.sp
                )
            }
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(NoteGreenText)
                        )
                        Text(
                            text = "All systems synced",
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 17.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Last backup: ${preferences.lastSyncedLabel} to Cloud",
                        fontFamily = QuicksandFontFamily,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(
                        onClick = onExport,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Export", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Medium)
                    }
                    Button(
                        onClick = onSyncNow,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        )
                    ) {
                        Icon(Icons.Filled.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sync Now", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}

// --- Settings Dialogs ---

@Composable
private fun ProfileEditDialog(
    preferences: UserPreferences,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var name by remember(preferences) { mutableStateOf(preferences.displayName) }
    var email by remember(preferences) { mutableStateOf(preferences.email) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Edit Profile", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AsyncImage(
                        model = IdeaPadAssets.PROFILE_AVATAR_IMAGE,
                        contentDescription = "Profile Picture",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                    )
                    Text(
                        text = "Creativity Hub Pro Member",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Display Name", fontFamily = QuicksandFontFamily) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email", fontFamily = QuicksandFontFamily) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(name.ifBlank { "Creative Thinker" }, email.ifBlank { "hello@ideapad.app" }) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = NoteYellowActive,
                    contentColor = NoteYellowText
                )
            ) {
                Text("Save", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", fontFamily = QuicksandFontFamily)
            }
        }
    )
}

@Composable
private fun DefaultNoteStyleDialog(
    preferences: UserPreferences,
    onDismiss: () -> Unit,
    onUpdatePreferences: ((UserPreferences) -> UserPreferences) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Default Note Style", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Text(
                    text = "DEFAULT STICKY COLOR",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    val swatches = listOf(
                        "yellow" to NoteYellowActive,
                        "pink" to NotePinkActive,
                        "green" to NoteGreenActive,
                        "neutral" to NoteNeutralCode
                    )
                    swatches.forEach { (key, color) ->
                        val selected = preferences.defaultNoteColor == key
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (selected) 3.dp else 1.dp,
                                    color = if (selected) MaterialTheme.colorScheme.primary else Color.Black.copy(alpha = 0.15f),
                                    shape = CircleShape
                                )
                                .clickable {
                                    onUpdatePreferences { it.copy(defaultNoteColor = key) }
                                }
                        )
                    }
                }

                Text(
                    text = "TYPOGRAPHY",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                val fonts = listOf(
                    Triple("bricolage", "Bricolage Grotesque", BricolageFontFamily),
                    Triple("quicksand", "Quicksand", QuicksandFontFamily),
                    Triple("mono", "Space Mono", SpaceMonoFontFamily)
                )
                fonts.forEach { (key, label, family) ->
                    val selected = preferences.defaultTypography == key
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (selected) NoteYellowActive.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surfaceContainerLow,
                        border = if (selected) BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onUpdatePreferences { it.copy(defaultTypography = key) }
                            }
                    ) {
                        Text(
                            text = label,
                            fontFamily = family,
                            fontSize = 17.sp,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                        )
                    }
                }

                HorizontalDivider()

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Snap Notes to Grid",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.Medium
                    )
                    Switch(
                        checked = preferences.snapToGrid,
                        onCheckedChange = { checked ->
                            onUpdatePreferences { it.copy(snapToGrid = checked) }
                        }
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = NoteYellowActive,
                    contentColor = NoteYellowText
                )
            ) {
                Text("Done", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
            }
        }
    )
}

@Composable
private fun ExportWorkspaceDialog(
    notes: List<IdeaNote>,
    onDismiss: () -> Unit,
    onRestoreStarter: () -> Unit
) {
    val activeCount = notes.count { it.status == "active" }
    val completedCount = notes.count { it.status == "completed" }
    val archivedCount = notes.count { it.status == "archived" }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("Sync & Export Summary", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Cloud Workspace Snapshot:",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = "• Active Board Notes: $activeCount\n• Done & Dusted: $completedCount\n• Archived Notes: $archivedCount",
                    fontFamily = QuicksandFontFamily,
                    fontSize = 14.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                OutlinedButton(
                    onClick = onRestoreStarter,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Restore IdeaPad Starter Notes", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Close", fontFamily = QuicksandFontFamily)
            }
        }
    )
}

@Composable
private fun HelpSupportDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text("IdeaPad Quick Guide", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "• Workspace: Toggle between the responsive Masonry Grid and the pannable Infinite Canvas.",
                    fontFamily = QuicksandFontFamily,
                    fontSize = 14.sp
                )
                Text(
                    text = "• Done & Dusted: Review finished thoughts with strikethrough styling or tap the check badge to reopen any note.",
                    fontFamily = QuicksandFontFamily,
                    fontSize = 14.sp
                )
                Text(
                    text = "• Customization: Switch between Bricolage Grotesque, Quicksand, and Space Mono fonts or Light/Dark themes anytime.",
                    fontFamily = QuicksandFontFamily,
                    fontSize = 14.sp
                )
            }
        },
        confirmButton = {
            Button(onClick = onDismiss) {
                Text("Got It", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
            }
        }
    )
}
