package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryLight = Color(0xFF695F00)
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = Color(0xFFFFEB3B)
val OnPrimaryContainerLight = Color(0xFF4F4800)
val PrimaryFixed = Color(0xFFF9E534)
val OnPrimaryFixed = Color(0xFF201C00)

val SecondaryLight = Color(0xFF964261)
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFFE97B9)
val OnSecondaryContainerLight = Color(0xFF792B4A)

val TertiaryLight = Color(0xFF286B33)
val OnTertiaryLight = Color(0xFFFFFFFF)
val TertiaryContainerLight = Color(0xFFB1FAB2)
val OnTertiaryContainerLight = Color(0xFF07521D)

val BackgroundLight = Color(0xFFF9F9FB)
val OnBackgroundLight = Color(0xFF1A1C1D)
val SurfaceLight = Color(0xFFF9F9FB)
val OnSurfaceLight = Color(0xFF1A1C1D)
val SurfaceVariantLight = Color(0xFFE2E2E4)
val OnSurfaceVariantLight = Color(0xFF4A4733)

val SurfaceContainerLowestLight = Color(0xFFFFFFFF)
val SurfaceContainerLowLight = Color(0xFFF3F3F5)
val SurfaceContainerLight = Color(0xFFEEEEF0)
val SurfaceContainerHighLight = Color(0xFFE8E8EA)
val SurfaceContainerHighestLight = Color(0xFFE2E2E4)

val OutlineLight = Color(0xFF7C7760)
val OutlineVariantLight = Color(0xFFCDC7AC)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF93000A)

val InverseSurfaceLight = Color(0xFF2F3132)
val InverseOnSurfaceLight = Color(0xFFF0F0F2)

// Dark Mode Tokens
val PrimaryDark = Color(0xFFDBC90A)
val OnPrimaryDark = Color(0xFF201C00)
val PrimaryContainerDark = Color(0xFF4F4800)
val OnPrimaryContainerDark = Color(0xFFF9E534)

val SecondaryDark = Color(0xFFFFB0C9)
val OnSecondaryDark = Color(0xFF5C1133)
val SecondaryContainerDark = Color(0xFF792B4A)
val OnSecondaryContainerDark = Color(0xFFFFD9E2)

val TertiaryDark = Color(0xFF90D792)
val OnTertiaryDark = Color(0xFF003910)
val TertiaryContainerDark = Color(0xFF07521D)
val OnTertiaryContainerDark = Color(0xFFABF4AC)

val BackgroundDark = Color(0xFF141617)
val OnBackgroundDark = Color(0xFFF0F0F2)
val SurfaceDark = Color(0xFF1A1C1D)
val OnSurfaceDark = Color(0xFFF0F0F2)
val SurfaceVariantDark = Color(0xFF323437)
val OnSurfaceVariantDark = Color(0xFFCDC7AC)

// Sticky Note Palette
val NoteYellowActive = Color(0xFFFFEB3B)
val NoteYellowSoft = Color(0xFFFFF9C4)
val NoteYellowCompleted = Color(0xFFFEF08A)
val NoteYellowText = Color(0xFF4F4800)

val NotePinkActive = Color(0xFFFE97B9)
val NotePinkSoft = Color(0xFFFCE4EC)
val NotePinkCompleted = Color(0xFFFECDD3)
val NotePinkText = Color(0xFF792B4A)

val NoteGreenActive = Color(0xFFB1FAB2)
val NoteGreenSoft = Color(0xFFE8F5E9)
val NoteGreenCompleted = Color(0xFFD9F99D)
val NoteGreenText = Color(0xFF286B33)

val NoteBlueActive = Color(0xFFE1F5FE)
val NoteBlueCompleted = Color(0xFFBAE6FD)
val NoteBlueText = Color(0xFF0369A1)

val NotePurpleActive = Color(0xFFE9D5FF)
val NotePurpleCompleted = Color(0xFFE9D5FF)
val NotePurpleText = Color(0xFF7E22CE)

val NoteNeutralActive = Color(0xFFFFFFFF)
val NoteNeutralCode = Color(0xFFE2E2E4)
val NoteNeutralCompleted = Color(0xFFE8E8EA)
val NoteNeutralText = Color(0xFF1A1C1D)

val NoteCoralActive = Color(0xFFFFDAD6)
val NoteCoralCompleted = Color(0xFFFFDAD6)
val NoteCoralText = Color(0xFF93000A)
