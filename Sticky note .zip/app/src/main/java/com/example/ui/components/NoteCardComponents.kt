package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.outlined.CheckBox
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.ShoppingCart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import coil.compose.AsyncImage
import com.example.util.ImageStorageHelper
import java.io.File
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.IdeaNote
import com.example.data.model.IdeaPadAssets
import com.example.ui.theme.InverseOnSurfaceLight
import com.example.ui.theme.InverseSurfaceLight
import com.example.ui.theme.NoteBlueActive
import com.example.ui.theme.NoteBlueCompleted
import com.example.ui.theme.NoteBlueText
import com.example.ui.theme.NoteCoralActive
import com.example.ui.theme.NoteCoralCompleted
import com.example.ui.theme.NoteCoralText
import com.example.ui.theme.NoteGreenActive
import com.example.ui.theme.NoteGreenCompleted
import com.example.ui.theme.NoteGreenSoft
import com.example.ui.theme.NoteGreenText
import com.example.ui.theme.NoteNeutralActive
import com.example.ui.theme.NoteNeutralCode
import com.example.ui.theme.NoteNeutralCompleted
import com.example.ui.theme.NoteNeutralText
import com.example.ui.theme.NotePinkActive
import com.example.ui.theme.NotePinkCompleted
import com.example.ui.theme.NotePinkSoft
import com.example.ui.theme.NotePinkText
import com.example.ui.theme.NotePurpleActive
import com.example.ui.theme.NotePurpleCompleted
import com.example.ui.theme.NotePurpleText
import com.example.ui.theme.NoteYellowActive
import com.example.ui.theme.NoteYellowCompleted
import com.example.ui.theme.NoteYellowSoft
import com.example.ui.theme.NoteYellowText
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.SpaceMonoFontFamily

data class NoteVisualStyle(
    val background: Color,
    val contentColor: Color,
    val accentColor: Color
)

fun resolveActiveNoteStyle(note: IdeaNote, isCanvasMode: Boolean): NoteVisualStyle {
    return when (note.colorTheme) {
        "pink" -> NoteVisualStyle(
            background = if (isCanvasMode) NotePinkSoft else NotePinkActive,
            contentColor = NotePinkText,
            accentColor = NotePinkText
        )
        "green" -> NoteVisualStyle(
            background = if (isCanvasMode) NoteGreenSoft else NoteGreenActive,
            contentColor = NoteGreenText,
            accentColor = NoteGreenText
        )
        "blue" -> NoteVisualStyle(
            background = NoteBlueActive,
            contentColor = NoteBlueText,
            accentColor = NoteBlueText
        )
        "purple" -> NoteVisualStyle(
            background = NotePurpleActive,
            contentColor = NotePurpleText,
            accentColor = NotePurpleText
        )
        "coral" -> NoteVisualStyle(
            background = NoteCoralActive,
            contentColor = NoteCoralText,
            accentColor = NoteCoralText
        )
        "neutral" -> {
            if (note.noteType == "code") {
                NoteVisualStyle(
                    background = NoteNeutralCode,
                    contentColor = Color(0xFF4A4733),
                    accentColor = Color(0xFF4A4733)
                )
            } else {
                NoteVisualStyle(
                    background = NoteNeutralActive,
                    contentColor = NoteNeutralText,
                    accentColor = Color(0xFF4A4733)
                )
            }
        }
        else -> NoteVisualStyle(
            background = if (isCanvasMode) NoteYellowSoft else NoteYellowActive,
            contentColor = if (note.title.startsWith("Idea:")) Color(0xFF201C00) else NoteYellowText,
            accentColor = NoteYellowText
        )
    }
}

fun resolveCompletedNoteStyle(note: IdeaNote): NoteVisualStyle {
    return when (note.colorTheme) {
        "blue" -> NoteVisualStyle(
            background = NoteBlueCompleted,
            contentColor = Color(0xFF0C4A6E),
            accentColor = Color(0xFF0369A1)
        )
        "pink" -> NoteVisualStyle(
            background = NotePinkCompleted,
            contentColor = Color(0xFF881337),
            accentColor = Color(0xFFBE123C)
        )
        "green" -> NoteVisualStyle(
            background = NoteGreenCompleted,
            contentColor = Color(0xFF365314),
            accentColor = Color(0xFF4D7C0F)
        )
        "purple" -> NoteVisualStyle(
            background = NotePurpleCompleted,
            contentColor = Color(0xFF7E22CE),
            accentColor = Color(0xFF7E22CE)
        )
        "coral" -> NoteVisualStyle(
            background = NoteCoralCompleted,
            contentColor = NoteCoralText,
            accentColor = NoteCoralText
        )
        "neutral" -> NoteVisualStyle(
            background = NoteNeutralCompleted,
            contentColor = Color(0xFF1A1C1D),
            accentColor = Color(0xFF4A4733)
        )
        else -> NoteVisualStyle(
            background = NoteYellowCompleted,
            contentColor = Color(0xFF746C00),
            accentColor = Color(0xFF5A5400)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ActiveWorkspaceNoteCard(
    note: IdeaNote,
    noteFontFamily: FontFamily,
    isCanvasMode: Boolean,
    onEdit: (IdeaNote) -> Unit,
    onMarkCompleted: (IdeaNote) -> Unit,
    onArchive: (IdeaNote) -> Unit,
    onTrash: (IdeaNote) -> Unit,
    onRestore: (IdeaNote) -> Unit,
    onDeleteForever: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val style = resolveActiveNoteStyle(note, isCanvasMode)
    var menuExpanded by remember { mutableStateOf(false) }

    // Image moodboard note has a sleek white border padding around the photo
    if (note.noteType == "image" && note.imageUrl.isNotBlank()) {
        Card(
            modifier = modifier
                .fillMaxWidth()
                .clickable { onEdit(note) }
                .testTag("workspace_note_card_${note.id}"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = style.background),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.25f))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Box {
                    AsyncImage(
                        model = note.imageUrl,
                        contentDescription = note.title.ifBlank { note.content },
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                    Box(modifier = Modifier.align(Alignment.TopEnd)) {
                        NoteActionMenuButton(
                            note = note,
                            tint = Color.White,
                            containerColor = Color.Black.copy(alpha = 0.35f),
                            expanded = menuExpanded,
                            onExpandedChange = { menuExpanded = it },
                            onEdit = { onEdit(note) },
                            onMarkCompleted = { onMarkCompleted(note) },
                            onArchive = { onArchive(note) },
                            onTrash = { onTrash(note) },
                            onRestore = { onRestore(note) },
                            onDeleteForever = { onDeleteForever(note.id) }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                    if (note.title.isNotBlank()) {
                        Text(
                            text = note.title,
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = style.contentColor
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    Text(
                        text = note.content,
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = style.accentColor
                    )
                }
            }
        }
        return
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onEdit(note) }
            .testTag("workspace_note_card_${note.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = style.background),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            // Header row if title is present or in canvas mode
            if (note.title.isNotBlank()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    val isFeatureCallout = note.title.startsWith("Idea:")
                    Text(
                        text = note.title,
                        fontFamily = if (isFeatureCallout) noteFontFamily else QuicksandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isFeatureCallout) 22.sp else 20.sp,
                        lineHeight = if (isFeatureCallout) 28.sp else 26.sp,
                        color = style.contentColor,
                        modifier = Modifier.weight(1f)
                    )
                    NoteActionMenuButton(
                        note = note,
                        tint = style.contentColor.copy(alpha = 0.75f),
                        containerColor = Color.Transparent,
                        expanded = menuExpanded,
                        onExpandedChange = { menuExpanded = it },
                        onEdit = { onEdit(note) },
                        onMarkCompleted = { onMarkCompleted(note) },
                        onArchive = { onArchive(note) },
                        onTrash = { onTrash(note) },
                        onRestore = { onRestore(note) },
                        onDeleteForever = { onDeleteForever(note.id) }
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        text = note.content,
                        fontFamily = noteFontFamily,
                        fontWeight = if (note.colorTheme == "pink") FontWeight.Medium else FontWeight.Normal,
                        fontSize = if (note.colorTheme == "pink") 18.sp else 19.sp,
                        lineHeight = if (note.colorTheme == "pink") 25.sp else 28.sp,
                        color = style.contentColor,
                        modifier = Modifier.weight(1f)
                    )
                    NoteActionMenuButton(
                        note = note,
                        tint = style.contentColor.copy(alpha = 0.7f),
                        containerColor = Color.Transparent,
                        expanded = menuExpanded,
                        onExpandedChange = { menuExpanded = it },
                        onEdit = { onEdit(note) },
                        onMarkCompleted = { onMarkCompleted(note) },
                        onArchive = { onArchive(note) },
                        onTrash = { onTrash(note) },
                        onRestore = { onRestore(note) },
                        onDeleteForever = { onDeleteForever(note.id) }
                    )
                }
            }

            // Code block if code note
            if (note.noteType == "code" && note.codeSnippet.isNotBlank()) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = InverseSurfaceLight,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 12.dp)
                ) {
                    Text(
                        text = note.codeSnippet,
                        fontFamily = SpaceMonoFontFamily,
                        fontSize = 13.sp,
                        lineHeight = 20.sp,
                        color = InverseOnSurfaceLight,
                        modifier = Modifier
                            .horizontalScroll(rememberScrollState())
                            .padding(16.dp)
                    )
                }
                if (note.title.isNotBlank()) {
                    Text(
                        text = note.content,
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = style.contentColor
                    )
                }
            } else if (note.noteType == "checklist" && note.checklistItems.isNotEmpty()) {
                if (note.title.isNotBlank() && note.content.isNotBlank()) {
                    Text(
                        text = note.content,
                        fontFamily = QuicksandFontFamily,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        color = style.contentColor.copy(alpha = 0.85f),
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                // Vertical left border checklist like Q3 Goals in Image 4
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(IntrinsicSize.Min)
                        .padding(vertical = 4.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .width(2.5.dp)
                            .fillMaxHeight()
                            .background(
                                style.contentColor.copy(alpha = 0.25f),
                                RoundedCornerShape(2.dp)
                            )
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        note.checklistItems.forEach { item ->
                            Text(
                                text = if (isCanvasMode) "- $item" else item,
                                fontFamily = noteFontFamily,
                                fontSize = 16.sp,
                                lineHeight = 22.sp,
                                color = style.contentColor
                            )
                        }
                    }
                }
            } else if (note.title.isNotBlank() && note.content.isNotBlank()) {
                Text(
                    text = note.content,
                    fontFamily = noteFontFamily,
                    fontSize = 17.sp,
                    lineHeight = 25.sp,
                    color = style.contentColor
                )
            }

            // Shopping cart icon row for pink quick shopping note
            if (note.colorTheme == "pink" && note.content.contains("coffee", ignoreCase = true)) {
                Spacer(modifier = Modifier.height(12.dp))
                Icon(
                    imageVector = Icons.Outlined.ShoppingCart,
                    contentDescription = "Shopping item",
                    tint = style.contentColor.copy(alpha = 0.65f),
                    modifier = Modifier.size(18.dp)
                )
            }

            // Tags Footer
            val visibleTags = note.tags.filter { !it.equals("Shopping", ignoreCase = true) }
            if (visibleTags.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    visibleTags.forEach { tag ->
                        val isActiveGreenBadge = tag.equals("Active", ignoreCase = true)
                        Surface(
                            shape = CircleShape,
                            color = if (isActiveGreenBadge) {
                                Color(0xFF4CAF50)
                            } else {
                                Color.Black.copy(alpha = 0.07f)
                            }
                        ) {
                            Text(
                                text = tag,
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = 0.5.sp,
                                color = if (isActiveGreenBadge) {
                                    Color.White
                                } else {
                                    style.contentColor.copy(alpha = 0.85f)
                                },
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CompletedNoteCard(
    note: IdeaNote,
    noteFontFamily: FontFamily,
    onToggleRestore: (IdeaNote) -> Unit,
    onEdit: (IdeaNote) -> Unit,
    onDelete: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val style = resolveCompletedNoteStyle(note)
    val grayscaleMatrix = remember { ColorMatrix().apply { setToSaturation(0.75f) } }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .alpha(0.9f)
            .clickable { onEdit(note) }
            .testTag("completed_note_card_${note.id}"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = style.background),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp)
            ) {
                if (note.title.isNotBlank()) {
                    Text(
                        text = note.title,
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 22.sp,
                        lineHeight = 28.sp,
                        color = style.accentColor,
                        textDecoration = TextDecoration.LineThrough,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(end = 42.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                } else {
                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Image if present (e.g. Inspiration Board or Client Presentation Deck)
                if (note.imageUrl.isNotBlank()) {
                    AsyncImage(
                        model = note.imageUrl,
                        contentDescription = note.title,
                        contentScale = ContentScale.Crop,
                        colorFilter = ColorFilter.colorMatrix(grayscaleMatrix),
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 10f)
                            .clip(RoundedCornerShape(14.dp))
                            .alpha(0.85f)
                            .background(Color.White.copy(alpha = 0.5f))
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                }

                // Checklist or Strikethrough text content
                if (note.noteType == "checklist" && note.checklistItems.isNotEmpty()) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        note.checklistItems.forEach { item ->
                            Row(
                                verticalAlignment = Alignment.Top,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Outlined.CheckBox,
                                    contentDescription = "Checked item",
                                    tint = style.contentColor,
                                    modifier = Modifier
                                        .padding(top = 3.dp)
                                        .size(20.dp)
                                )
                                Text(
                                    text = item,
                                    fontFamily = noteFontFamily,
                                    fontSize = 18.sp,
                                    lineHeight = 26.sp,
                                    color = style.contentColor,
                                    textDecoration = TextDecoration.LineThrough
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(18.dp))
                } else if (note.noteType != "image" || note.title == "Client Presentation Deck") {
                    val paragraphs = note.content.split("\n\n")
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        paragraphs.forEach { paragraph ->
                            Text(
                                text = paragraph,
                                fontFamily = noteFontFamily,
                                fontSize = if (note.title.isBlank()) 22.sp else 18.sp,
                                lineHeight = if (note.title.isBlank()) 30.sp else 27.sp,
                                color = style.contentColor,
                                textDecoration = TextDecoration.LineThrough,
                                modifier = if (note.title.isBlank()) Modifier.padding(end = 36.dp) else Modifier
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(18.dp))
                }

                // Tags & Date Footer
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f, fill = false)
                    ) {
                        note.tags.forEach { tag ->
                            Surface(
                                shape = CircleShape,
                                color = style.accentColor.copy(alpha = 0.12f)
                            ) {
                                Text(
                                    text = tag.uppercase(),
                                    fontFamily = QuicksandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    letterSpacing = 0.6.sp,
                                    color = style.accentColor,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                                )
                            }
                        }
                    }

                    if (note.dateLabel.isNotBlank()) {
                        Text(
                            text = note.dateLabel,
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = style.accentColor.copy(alpha = 0.55f),
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }
            }

            // Top-right Check Circle Badge (tap to restore to active Workspace)
            Surface(
                shape = CircleShape,
                color = Color.White.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f)),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(14.dp)
                    .size(34.dp)
                    .clip(CircleShape)
                    .clickable { onToggleRestore(note) }
                    .testTag("restore_completed_note_${note.id}")
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = Icons.Outlined.CheckCircle,
                        contentDescription = "Completed - Tap to reopen in Workspace",
                        tint = style.accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun NoteActionMenuButton(
    note: IdeaNote,
    tint: Color,
    containerColor: Color,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    onEdit: () -> Unit,
    onMarkCompleted: () -> Unit,
    onArchive: () -> Unit,
    onTrash: () -> Unit,
    onRestore: () -> Unit,
    onDeleteForever: () -> Unit
) {
    Box {
        IconButton(
            onClick = { onExpandedChange(true) },
            modifier = Modifier
                .size(36.dp)
                .background(containerColor, CircleShape)
                .testTag("note_more_button_${note.id}")
        ) {
            Icon(
                imageVector = Icons.Filled.MoreHoriz,
                contentDescription = "Note options",
                tint = tint,
                modifier = Modifier.size(20.dp)
            )
        }
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { onExpandedChange(false) }
        ) {
            DropdownMenuItem(
                text = { Text("Open Full Note", fontFamily = QuicksandFontFamily) },
                leadingIcon = { Icon(Icons.Filled.Edit, contentDescription = null) },
                onClick = {
                    onExpandedChange(false)
                    onEdit()
                }
            )
            if (note.status != "completed") {
                DropdownMenuItem(
                    text = { Text("Mark Completed", fontFamily = QuicksandFontFamily) },
                    leadingIcon = { Icon(Icons.Filled.CheckCircle, contentDescription = null) },
                    onClick = {
                        onExpandedChange(false)
                        onMarkCompleted()
                    }
                )
            }
            if (note.status != "active") {
                DropdownMenuItem(
                    text = { Text("Restore to Board", fontFamily = QuicksandFontFamily) },
                    leadingIcon = { Icon(Icons.Filled.Restore, contentDescription = null) },
                    onClick = {
                        onExpandedChange(false)
                        onRestore()
                    }
                )
            }
            if (note.status != "archived") {
                DropdownMenuItem(
                    text = { Text("Archive", fontFamily = QuicksandFontFamily) },
                    leadingIcon = { Icon(Icons.Filled.Archive, contentDescription = null) },
                    onClick = {
                        onExpandedChange(false)
                        onArchive()
                    }
                )
            }
            if (note.status != "trashed") {
                DropdownMenuItem(
                    text = { Text("Move to Trash", fontFamily = QuicksandFontFamily) },
                    leadingIcon = { Icon(Icons.Filled.Delete, contentDescription = null) },
                    onClick = {
                        onExpandedChange(false)
                        onTrash()
                    }
                )
            } else {
                DropdownMenuItem(
                    text = {
                        Text(
                            "Delete Permanently",
                            fontFamily = QuicksandFontFamily,
                            color = MaterialTheme.colorScheme.error
                        )
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Filled.Delete,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                    },
                    onClick = {
                        onExpandedChange(false)
                        onDeleteForever()
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun NoteEditorDialog(
    initialNote: IdeaNote?,
    defaultColor: String,
    onDismiss: () -> Unit,
    onSave: (
        title: String,
        content: String,
        noteType: String,
        colorTheme: String,
        tagsInput: String,
        checklistInput: String,
        imageUrl: String,
        codeSnippet: String
    ) -> Unit,
    onChangeStatus: ((String) -> Unit)? = null,
    onDelete: (() -> Unit)? = null,
    noteFontFamily: FontFamily = QuicksandFontFamily
) {
    BackHandler(onBack = onDismiss)

    val derivedInitialHeading = remember(initialNote) {
        when {
            initialNote == null -> ""
            initialNote.title.isNotBlank() -> initialNote.title
            initialNote.content.isNotBlank() -> {
                initialNote.content.lineSequence().firstOrNull()?.take(48)?.trim().orEmpty()
            }
            else -> "Untitled Note"
        }
    }

    var title by remember(initialNote) { mutableStateOf(derivedInitialHeading) }
    var content by remember(initialNote) { mutableStateOf(initialNote?.content ?: "") }
    var noteType by remember(initialNote) { mutableStateOf(initialNote?.noteType ?: "text") }
    var colorTheme by remember(initialNote) { mutableStateOf(initialNote?.colorTheme ?: defaultColor) }
    var tagsInput by remember(initialNote) {
        mutableStateOf(initialNote?.tags?.joinToString(", ") ?: "Design")
    }
    var checklistInput by remember(initialNote) {
        mutableStateOf(
            initialNote?.checklistItems?.joinToString("\n")
                ?: "Launch new feature set\nUpdate documentation\nRefine animation curves"
        )
    }
    var newChecklistItemText by remember(initialNote) { mutableStateOf("") }
    var imageUrl by remember(initialNote) {
        mutableStateOf(initialNote?.imageUrl ?: "")
    }
    var codeSnippet by remember(initialNote) {
        mutableStateOf(
            initialNote?.codeSnippet?.ifBlank {
                "const toggleTheme = () => {\n  document.body.classList.toggle('dark');\n};"
            } ?: "const toggleTheme = () => {\n  document.body.classList.toggle('dark');\n};"
        )
    }

    val context = LocalContext.current
    var currentCameraTempFile by remember { mutableStateOf<File?>(null) }
    var showUrlFallback by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val localPath = ImageStorageHelper.copyUriToInternalStorage(context, uri)
            if (localPath != null) {
                imageUrl = localPath
            }
        }
    }

    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicture()
    ) { success: Boolean ->
        if (success && currentCameraTempFile != null) {
            val localPath = ImageStorageHelper.persistCameraImage(context, currentCameraTempFile!!)
            imageUrl = localPath
        }
    }

    val colorOptions = listOf(
        "yellow" to NoteYellowActive,
        "pink" to NotePinkActive,
        "green" to NoteGreenActive,
        "blue" to NoteBlueCompleted,
        "purple" to NotePurpleCompleted,
        "neutral" to NoteNeutralCode,
        "coral" to NoteCoralActive
    )

    val typeOptions = listOf(
        "text" to "Note",
        "checklist" to "Checklist",
        "image" to "Moodboard",
        "code" to "Code"
    )

    val previewNote = remember(title, content, noteType, colorTheme) {
        IdeaNote(
            title = title,
            content = content,
            noteType = noteType,
            colorTheme = colorTheme
        )
    }
    val activeStyle = resolveActiveNoteStyle(previewNote, isCanvasMode = false)

    val parsedTags = remember(tagsInput) {
        tagsInput.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    }
    val suggestedTags = listOf("Design", "Urgent", "Planning", "Active", "Research", "Personal", "Dev")

    val saveAndClose = {
        onSave(
            title.trim(),
            content,
            noteType,
            colorTheme,
            tagsInput,
            checklistInput,
            if (noteType == "image") imageUrl else "",
            if (noteType == "code") codeSnippet else ""
        )
        onDismiss()
    }

    // Full-Page Note Screen (replaces the old modal pop-up dialog)
    Surface(
        color = MaterialTheme.colorScheme.background,
        modifier = Modifier
            .fillMaxSize()
            .testTag("full_page_note_editor")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .imePadding()
        ) {
            // Full-Page Sticky Header Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp,
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .clickable { onDismiss() }
                                .testTag("close_note_editor_button")
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back to notes",
                                    tint = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        Column {
                            Text(
                                text = if (initialNote == null) "New Canvas Note" else "Full Page Note",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                val statusLabel = (initialNote?.status ?: "active").uppercase()
                                Surface(
                                    shape = CircleShape,
                                    color = activeStyle.background
                                ) {
                                    Text(
                                        text = statusLabel,
                                        fontFamily = QuicksandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        color = activeStyle.contentColor,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                if (!initialNote?.dateLabel.isNullOrBlank()) {
                                    Text(
                                        text = "• ${initialNote?.dateLabel}",
                                        fontFamily = QuicksandFontFamily,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (initialNote != null && onChangeStatus != null) {
                            IconButton(
                                onClick = {
                                    val nextStatus = if (initialNote.status == "completed") "active" else "completed"
                                    onChangeStatus(nextStatus)
                                    onDismiss()
                                }
                            ) {
                                Icon(
                                    imageVector = if (initialNote.status == "completed") {
                                        Icons.Filled.Restore
                                    } else {
                                        Icons.Filled.CheckCircle
                                    },
                                    contentDescription = if (initialNote.status == "completed") "Reopen Note" else "Mark Completed",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Button(
                            onClick = saveAndClose,
                            shape = CircleShape,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NoteYellowActive,
                                contentColor = NoteYellowText
                            ),
                            modifier = Modifier
                                .height(44.dp)
                                .testTag("save_note_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Save Note",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // Full-Page Scrollable Document Area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.TopCenter
            ) {
                Column(
                    modifier = Modifier
                        .widthIn(max = 820.dp)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 18.dp, vertical = 18.dp),
                    verticalArrangement = Arrangement.spacedBy(18.dp)
                ) {
                    // Live Selectable Sticky Note Banner at Top of Full Page
                    Card(
                        shape = RoundedCornerShape(22.dp),
                        colors = CardDefaults.cardColors(containerColor = activeStyle.background),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        border = BorderStroke(1.dp, activeStyle.contentColor.copy(alpha = 0.14f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SelectionContainer {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "SELECTED NOTE PREVIEW • TAP OR DRAG TO SELECT TEXT",
                                        fontFamily = QuicksandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        letterSpacing = 0.8.sp,
                                        color = activeStyle.contentColor.copy(alpha = 0.65f)
                                    )
                                    Text(
                                        text = colorTheme.uppercase(),
                                        fontFamily = QuicksandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = activeStyle.contentColor.copy(alpha = 0.75f)
                                    )
                                }

                                Text(
                                    text = title.ifBlank { "Untitled Note Heading" },
                                    fontFamily = QuicksandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 24.sp,
                                    lineHeight = 30.sp,
                                    color = activeStyle.contentColor
                                )

                                if (content.isNotBlank()) {
                                    Text(
                                        text = content,
                                        fontFamily = noteFontFamily,
                                        fontSize = 16.sp,
                                        lineHeight = 24.sp,
                                        color = activeStyle.contentColor.copy(alpha = 0.9f)
                                    )
                                }
                            }
                        }
                    }

                    // Studio Controls: Note Type & Sticky Color
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.45f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            Text(
                                text = "NOTE FORMAT & STICKY COLOR",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 0.7.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                typeOptions.forEach { (key, label) ->
                                    FilterChip(
                                        selected = noteType == key,
                                        onClick = { noteType = key },
                                        label = {
                                            Text(
                                                text = label,
                                                fontFamily = QuicksandFontFamily,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                        }
                                    )
                                }
                            }

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                colorOptions.forEach { (key, color) ->
                                    val selected = colorTheme == key
                                    Box(
                                        contentAlignment = Alignment.Center,
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(color)
                                            .border(
                                                width = if (selected) 2.5.dp else 1.dp,
                                                color = if (selected) {
                                                    MaterialTheme.colorScheme.primary
                                                } else {
                                                    Color.Black.copy(alpha = 0.15f)
                                                },
                                                shape = CircleShape
                                            )
                                            .clickable { colorTheme = key }
                                    ) {
                                        if (selected) {
                                            Icon(
                                                imageVector = Icons.Filled.Check,
                                                contentDescription = "Selected color $key",
                                                tint = Color.Black.copy(alpha = 0.75f),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Full-Page Heading & Content Editor Sheet
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "HEADING & DETAILS",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 0.7.sp,
                                color = MaterialTheme.colorScheme.primary
                            )

                            OutlinedTextField(
                                value = title,
                                onValueChange = { title = it },
                                label = {
                                    Text(
                                        text = "Note Heading",
                                        fontFamily = QuicksandFontFamily,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "Enter a clear heading for your note...",
                                        fontFamily = QuicksandFontFamily
                                    )
                                },
                                textStyle = TextStyle(
                                    fontFamily = QuicksandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 20.sp,
                                    lineHeight = 26.sp
                                ),
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("note_title_input")
                            )

                            OutlinedTextField(
                                value = content,
                                onValueChange = { content = it },
                                label = {
                                    Text(
                                        text = "Thought / Description",
                                        fontFamily = QuicksandFontFamily,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                },
                                placeholder = {
                                    Text(
                                        text = "Write your full thoughts, meeting notes, or ideas here...",
                                        fontFamily = QuicksandFontFamily
                                    )
                                },
                                textStyle = TextStyle(
                                    fontFamily = noteFontFamily,
                                    fontSize = 17.sp,
                                    lineHeight = 25.sp
                                ),
                                minLines = 6,
                                shape = RoundedCornerShape(14.dp),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = MaterialTheme.colorScheme.primary,
                                    unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("note_content_input")
                            )
                        }
                    }

                    // Checklist Section (Full-Page Interactive Items + Multi-line Editor)
                    if (noteType == "checklist") {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            val currentItems = remember(checklistInput) {
                                checklistInput.lines().map { it.trim() }.filter { it.isNotEmpty() }
                            }
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "CHECKLIST ITEMS (${currentItems.size})",
                                    fontFamily = QuicksandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    letterSpacing = 0.7.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )

                                // Interactive individual checklist items with SelectionContainer
                                if (currentItems.isNotEmpty()) {
                                    SelectionContainer {
                                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            currentItems.forEachIndexed { index, item ->
                                                Surface(
                                                    shape = RoundedCornerShape(12.dp),
                                                    color = activeStyle.background.copy(alpha = 0.55f),
                                                    border = BorderStroke(1.dp, activeStyle.contentColor.copy(alpha = 0.12f)),
                                                    modifier = Modifier.fillMaxWidth()
                                                ) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Row(
                                                            verticalAlignment = Alignment.CenterVertically,
                                                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                            modifier = Modifier.weight(1f)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Filled.CheckBox,
                                                                contentDescription = null,
                                                                tint = activeStyle.contentColor,
                                                                modifier = Modifier.size(18.dp)
                                                            )
                                                            Text(
                                                                text = item,
                                                                fontFamily = noteFontFamily,
                                                                fontSize = 16.sp,
                                                                color = activeStyle.contentColor
                                                            )
                                                        }
                                                        IconButton(
                                                            onClick = {
                                                                val updated = currentItems.toMutableList().also {
                                                                    it.removeAt(index)
                                                                }
                                                                checklistInput = updated.joinToString("\n")
                                                            },
                                                            modifier = Modifier.size(32.dp)
                                                        ) {
                                                            Icon(
                                                                imageVector = Icons.Filled.Close,
                                                                contentDescription = "Remove checklist item",
                                                                tint = activeStyle.contentColor.copy(alpha = 0.65f),
                                                                modifier = Modifier.size(16.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Quick Add Checklist Item Row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    OutlinedTextField(
                                        value = newChecklistItemText,
                                        onValueChange = { newChecklistItemText = it },
                                        placeholder = {
                                            Text("Add a new checklist item...", fontFamily = QuicksandFontFamily)
                                        },
                                        singleLine = true,
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f)
                                    )
                                    Button(
                                        onClick = {
                                            val trimmed = newChecklistItemText.trim()
                                            if (trimmed.isNotEmpty()) {
                                                checklistInput = if (checklistInput.isBlank()) {
                                                    trimmed
                                                } else {
                                                    "$checklistInput\n$trimmed"
                                                }
                                                newChecklistItemText = ""
                                            }
                                        },
                                        shape = RoundedCornerShape(12.dp),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = NoteYellowActive,
                                            contentColor = NoteYellowText
                                        ),
                                        modifier = Modifier.height(52.dp)
                                    ) {
                                        Icon(Icons.Filled.Add, contentDescription = "Add item")
                                    }
                                }

                                OutlinedTextField(
                                    value = checklistInput,
                                    onValueChange = { checklistInput = it },
                                    label = {
                                        Text("Edit All Checklist Lines (one per line)", fontFamily = QuicksandFontFamily)
                                    },
                                    minLines = 4,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("note_checklist_input")
                                )
                            }
                        }
                    }

                    // Moodboard Photo Section (Gallery & Camera on Full Page)
                    if (noteType == "image") {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.5f))
                                .border(
                                    1.dp,
                                    MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f),
                                    RoundedCornerShape(20.dp)
                                )
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "MOODBOARD PHOTO",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 0.7.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            // Preview Box if image selected
                            if (imageUrl.isNotBlank()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(240.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color.Black.copy(alpha = 0.05f))
                                ) {
                                    AsyncImage(
                                        model = imageUrl,
                                        contentDescription = "Selected note image",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    Surface(
                                        shape = CircleShape,
                                        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.88f),
                                        shadowElevation = 2.dp,
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(10.dp)
                                            .size(38.dp)
                                            .clickable { imageUrl = "" }
                                            .testTag("remove_image_button")
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = Icons.Filled.Close,
                                                contentDescription = "Remove photo",
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            } else {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.surfaceContainerLowest,
                                    border = BorderStroke(
                                        1.dp,
                                        MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.PhotoLibrary,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(36.dp)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "Add a photo from your device gallery or camera",
                                            fontFamily = QuicksandFontFamily,
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }

                            // Direct Action Buttons: Gallery & Camera
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Button(
                                    onClick = {
                                        photoPickerLauncher.launch(
                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                        )
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NoteYellowActive,
                                        contentColor = NoteYellowText
                                    ),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("gallery_picker_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PhotoLibrary,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Gallery",
                                        fontFamily = QuicksandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }

                                OutlinedButton(
                                    onClick = {
                                        val pair = ImageStorageHelper.createCameraImageUri(context)
                                        if (pair != null) {
                                            currentCameraTempFile = pair.first
                                            cameraLauncher.launch(pair.second)
                                        }
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("camera_capture_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.PhotoCamera,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "Camera",
                                        fontFamily = QuicksandFontFamily,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            // Secondary expandable option for web image URL
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(
                                    onClick = { showUrlFallback = !showUrlFallback }
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Link,
                                        contentDescription = null,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (showUrlFallback) "Hide web URL input" else "Or use web image link",
                                        fontFamily = QuicksandFontFamily,
                                        fontSize = 12.sp
                                    )
                                }
                            }

                            if (showUrlFallback) {
                                OutlinedTextField(
                                    value = imageUrl,
                                    onValueChange = { imageUrl = it },
                                    label = { Text("Web Image URL", fontFamily = QuicksandFontFamily, fontSize = 12.sp) },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("note_image_url_fallback_input")
                                )
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    TextButton(onClick = { imageUrl = IdeaPadAssets.MOODBOARD_DESK_IMAGE }) {
                                        Text("Desk", fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { imageUrl = IdeaPadAssets.INSPIRATION_WALL_IMAGE }) {
                                        Text("Sticky Wall", fontSize = 11.sp)
                                    }
                                    TextButton(onClick = { imageUrl = IdeaPadAssets.PRESENTATION_DECK_IMAGE }) {
                                        Text("Slide Deck", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    // Code Snippet Studio Section
                    if (noteType == "code") {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Text(
                                    text = "CODE SNIPPET",
                                    fontFamily = QuicksandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    letterSpacing = 0.7.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                OutlinedTextField(
                                    value = codeSnippet,
                                    onValueChange = { codeSnippet = it },
                                    label = { Text("Code Snippet", fontFamily = SpaceMonoFontFamily) },
                                    textStyle = TextStyle(
                                        fontFamily = SpaceMonoFontFamily,
                                        fontSize = 14.sp,
                                        lineHeight = 21.sp
                                    ),
                                    minLines = 6,
                                    shape = RoundedCornerShape(14.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("note_code_input")
                                )
                            }
                        }
                    }

                    // Tags & Organization Section
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(18.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                text = "TAGS & LABELS",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 0.7.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                suggestedTags.forEach { tag ->
                                    val isSelected = parsedTags.any { it.equals(tag, ignoreCase = true) }
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            val updated = if (isSelected) {
                                                parsedTags.filterNot { it.equals(tag, ignoreCase = true) }
                                            } else {
                                                parsedTags + tag
                                            }
                                            tagsInput = updated.joinToString(", ")
                                        },
                                        label = {
                                            Text(
                                                text = tag,
                                                fontFamily = QuicksandFontFamily,
                                                fontWeight = FontWeight.SemiBold,
                                                fontSize = 12.sp
                                            )
                                        }
                                    )
                                }
                            }

                            OutlinedTextField(
                                value = tagsInput,
                                onValueChange = { tagsInput = it },
                                label = { Text("Tags (comma separated)", fontFamily = QuicksandFontFamily) },
                                singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("note_tags_input")
                            )
                        }
                    }

                    // Status & Delete Actions for Existing Notes
                    if (initialNote != null && onChangeStatus != null) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (initialNote.status != "completed") {
                                OutlinedButton(
                                    onClick = {
                                        onChangeStatus("completed")
                                        onDismiss()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.CheckCircle,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Complete", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
                                }
                            } else {
                                OutlinedButton(
                                    onClick = {
                                        onChangeStatus("active")
                                        onDismiss()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Restore,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Reopen", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (initialNote.status != "archived") {
                                OutlinedButton(
                                    onClick = {
                                        onChangeStatus("archived")
                                        onDismiss()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Archive,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Archive", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (onDelete != null) {
                                OutlinedButton(
                                    onClick = {
                                        onDelete()
                                        onDismiss()
                                    },
                                    shape = RoundedCornerShape(12.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        contentColor = MaterialTheme.colorScheme.error
                                    ),
                                    modifier = Modifier.height(48.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Delete,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Delete", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    // Full-Width Bottom Save & Cancel Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 4.dp, bottom = 24.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(52.dp)
                        ) {
                            Text(
                                text = "Back to Board",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                        Button(
                            onClick = saveAndClose,
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NoteYellowActive,
                                contentColor = NoteYellowText
                            ),
                            modifier = Modifier
                                .weight(1.4f)
                                .height(52.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Check,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (initialNote == null) "Create Note" else "Save Changes",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

