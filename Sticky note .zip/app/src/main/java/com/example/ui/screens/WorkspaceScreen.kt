package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.staggeredgrid.LazyVerticalStaggeredGrid
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridCells
import androidx.compose.foundation.lazy.staggeredgrid.StaggeredGridItemSpan
import androidx.compose.foundation.lazy.staggeredgrid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.IdeaNote
import com.example.data.model.UserPreferences
import com.example.ui.components.ActiveWorkspaceNoteCard
import com.example.ui.theme.NoteYellowActive
import com.example.ui.theme.NoteYellowText
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.viewmodel.WorkspaceLayoutMode
import com.example.ui.viewmodel.WorkspaceSubTab
import kotlin.math.roundToInt

@Composable
fun WorkspaceScreen(
    notes: List<IdeaNote>,
    subTab: WorkspaceSubTab,
    layoutMode: WorkspaceLayoutMode,
    preferences: UserPreferences,
    noteFontFamily: FontFamily,
    isExpandedScreen: Boolean,
    onSubTabChange: (WorkspaceSubTab) -> Unit,
    onToggleLayoutMode: () -> Unit,
    onNewNoteClick: () -> Unit,
    onEditNote: (IdeaNote) -> Unit,
    onMarkCompleted: (IdeaNote) -> Unit,
    onArchiveNote: (IdeaNote) -> Unit,
    onTrashNote: (IdeaNote) -> Unit,
    onRestoreNote: (IdeaNote) -> Unit,
    onDeleteNoteForever: (String) -> Unit,
    onUpdateCanvasPosition: (IdeaNote, Float, Float) -> Unit,
    onEmptyTrash: () -> Unit,
    onRestoreStarterNotes: () -> Unit,
    modifier: Modifier = Modifier
) {
    val gridSpacingDp = when (preferences.gridDensity) {
        1L -> 40.dp
        3L -> 20.dp
        else -> 32.dp
    }
    val lineColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.04f)
    val dotColor = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.55f)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .drawBehind {
                if (preferences.canvasGridEnabled) {
                    val step = gridSpacingDp.toPx()
                    if (layoutMode == WorkspaceLayoutMode.INFINITE_CANVAS) {
                        var x = step / 2f
                        while (x < size.width) {
                            var y = step / 2f
                            while (y < size.height) {
                                drawCircle(
                                    color = dotColor,
                                    radius = 1.6.dp.toPx(),
                                    center = Offset(x, y)
                                )
                                y += step
                            }
                            x += step
                        }
                    } else {
                        var x = 0f
                        while (x < size.width) {
                            drawLine(
                                color = lineColor,
                                start = Offset(x, 0f),
                                end = Offset(x, size.height),
                                strokeWidth = 1f
                            )
                            x += step
                        }
                        var y = 0f
                        while (y < size.height) {
                            drawLine(
                                color = lineColor,
                                start = Offset(0f, y),
                                end = Offset(size.width, y),
                                strokeWidth = 1f
                            )
                            y += step
                        }
                    }
                }
            }
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Compact Sub-Toolbar: Board / Archive / Trash + Masonry vs Infinite Canvas switch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (!isExpandedScreen) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SubTabChip(
                            label = "Board",
                            selected = subTab == WorkspaceSubTab.BOARD,
                            onClick = { onSubTabChange(WorkspaceSubTab.BOARD) },
                            tag = "subtab_board"
                        )
                        SubTabChip(
                            label = "Archive",
                            selected = subTab == WorkspaceSubTab.ARCHIVE,
                            onClick = { onSubTabChange(WorkspaceSubTab.ARCHIVE) },
                            tag = "subtab_archive"
                        )
                        SubTabChip(
                            label = "Trash",
                            selected = subTab == WorkspaceSubTab.TRASH,
                            onClick = { onSubTabChange(WorkspaceSubTab.TRASH) },
                            tag = "subtab_trash"
                        )
                    }
                } else {
                    Text(
                        text = when (subTab) {
                            WorkspaceSubTab.BOARD -> "Creativity Hub • Workspace Board"
                            WorkspaceSubTab.ARCHIVE -> "Creativity Hub • Archive"
                            WorkspaceSubTab.TRASH -> "Creativity Hub • Trash"
                        },
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (subTab == WorkspaceSubTab.TRASH && notes.isNotEmpty()) {
                        OutlinedButton(
                            onClick = onEmptyTrash,
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            shape = CircleShape
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteSweep,
                                contentDescription = "Empty Trash",
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Empty",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                    }

                    if (subTab == WorkspaceSubTab.BOARD) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainerHigh,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable { onToggleLayoutMode() }
                                .testTag("toggle_canvas_mode_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = if (layoutMode == WorkspaceLayoutMode.MASONRY) {
                                        Icons.Filled.OpenWith
                                    } else {
                                        Icons.Filled.GridView
                                    },
                                    contentDescription = "Switch layout mode",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = if (layoutMode == WorkspaceLayoutMode.MASONRY) {
                                        "Infinite Canvas"
                                    } else {
                                        "Masonry Grid"
                                    },
                                    fontFamily = QuicksandFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                }
            }

            val viewKey = if (notes.isEmpty()) "empty" else if (subTab == WorkspaceSubTab.BOARD && layoutMode == WorkspaceLayoutMode.INFINITE_CANVAS) "canvas" else "grid_${subTab.name}"
            AnimatedContent(
                targetState = viewKey,
                transitionSpec = {
                    if (preferences.reduceMotion) {
                        fadeIn(animationSpec = tween(50)) togetherWith fadeOut(animationSpec = tween(50))
                    } else {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(150))
                    }
                },
                label = "workspace_view_anim",
                modifier = Modifier.fillMaxSize()
            ) { targetView ->
                when (targetView) {
                    "empty" -> {
                        EmptyWorkspaceState(
                            subTab = subTab,
                            onNewNoteClick = onNewNoteClick,
                            onRestoreStarterNotes = onRestoreStarterNotes
                        )
                    }
                    "canvas" -> {
                        InfiniteDraggableCanvas(
                            notes = notes,
                            noteFontFamily = noteFontFamily,
                            reduceMotion = preferences.reduceMotion,
                            onEditNote = onEditNote,
                            onMarkCompleted = onMarkCompleted,
                            onArchiveNote = onArchiveNote,
                            onTrashNote = onTrashNote,
                            onRestoreNote = onRestoreNote,
                            onDeleteNoteForever = onDeleteNoteForever,
                            onUpdateCanvasPosition = onUpdateCanvasPosition
                        )
                    }
                    else -> {
                        LazyVerticalStaggeredGrid(
                            columns = if (isExpandedScreen) {
                                StaggeredGridCells.Adaptive(minSize = 300.dp)
                            } else {
                                StaggeredGridCells.Fixed(1)
                            },
                            contentPadding = PaddingValues(
                                start = 16.dp,
                                end = 16.dp,
                                top = 8.dp,
                                bottom = 112.dp
                            ),
                            horizontalArrangement = Arrangement.spacedBy(16.dp),
                            verticalItemSpacing = 16.dp,
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("workspace_masonry_grid")
                        ) {
                            if (subTab != WorkspaceSubTab.BOARD) {
                                item(span = StaggeredGridItemSpan.FullLine) {
                                    Column(modifier = Modifier.padding(bottom = 4.dp)) {
                                        Text(
                                            text = if (subTab == WorkspaceSubTab.ARCHIVE) "Archived Thoughts" else "Trash Bin",
                                            fontFamily = QuicksandFontFamily,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 24.sp,
                                            color = MaterialTheme.colorScheme.onBackground
                                        )
                                        Text(
                                            text = if (subTab == WorkspaceSubTab.ARCHIVE) {
                                                "Reference ideas tucked away from your active board."
                                            } else {
                                                "Notes in trash can be restored to your workspace or deleted forever."
                                            },
                                            fontFamily = QuicksandFontFamily,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            items(notes, key = { it.id }) { note ->
                                ActiveWorkspaceNoteCard(
                                    note = note,
                                    noteFontFamily = noteFontFamily,
                                    isCanvasMode = false,
                                    onEdit = onEditNote,
                                    onMarkCompleted = onMarkCompleted,
                                    onArchive = onArchiveNote,
                                    onTrash = onTrashNote,
                                    onRestore = onRestoreNote,
                                    onDeleteForever = onDeleteNoteForever
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun InfiniteDraggableCanvas(
    notes: List<IdeaNote>,
    noteFontFamily: FontFamily,
    reduceMotion: Boolean,
    onEditNote: (IdeaNote) -> Unit,
    onMarkCompleted: (IdeaNote) -> Unit,
    onArchiveNote: (IdeaNote) -> Unit,
    onTrashNote: (IdeaNote) -> Unit,
    onRestoreNote: (IdeaNote) -> Unit,
    onDeleteNoteForever: (String) -> Unit,
    onUpdateCanvasPosition: (IdeaNote, Float, Float) -> Unit
) {
    val density = LocalDensity.current
    var panOffsetX by remember { mutableFloatStateOf(0f) }
    var panOffsetY by remember { mutableFloatStateOf(0f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    panOffsetX = (panOffsetX + dragAmount.x).coerceIn(-1800f, 600f)
                    panOffsetY = (panOffsetY + dragAmount.y).coerceIn(-1800f, 600f)
                }
            }
            .testTag("infinite_canvas_surface")
    ) {
        notes.forEach { note ->
            val initialPxX = with(density) { note.canvasX.toInt().dp.toPx() }
            val initialPxY = with(density) { note.canvasY.toInt().dp.toPx() }
            var localDragX by remember(note.id, note.canvasX) { mutableFloatStateOf(initialPxX) }
            var localDragY by remember(note.id, note.canvasY) { mutableFloatStateOf(initialPxY) }

            val cardWidth = when {
                note.noteType == "checklist" && note.title.isNotBlank() -> 360.dp
                note.colorTheme == "blue" -> 280.dp
                else -> 310.dp
            }
            val tilt = if (reduceMotion) 0f else note.rotationDeg.toFloat()

            Box(
                modifier = Modifier
                    .offset {
                        IntOffset(
                            x = (localDragX + panOffsetX).roundToInt(),
                            y = (localDragY + panOffsetY).roundToInt()
                        )
                    }
                    .width(cardWidth)
                    .rotate(tilt)
                    .pointerInput(note.id) {
                        detectDragGestures(
                            onDragEnd = {
                                val dpX = with(density) { localDragX.toDp().value }
                                val dpY = with(density) { localDragY.toDp().value }
                                onUpdateCanvasPosition(note, dpX, dpY)
                            }
                        ) { change, dragAmount ->
                            change.consume()
                            localDragX = (localDragX + dragAmount.x).coerceIn(0f, 3500f)
                            localDragY = (localDragY + dragAmount.y).coerceIn(0f, 3500f)
                        }
                    }
            ) {
                ActiveWorkspaceNoteCard(
                    note = note,
                    noteFontFamily = noteFontFamily,
                    isCanvasMode = true,
                    onEdit = onEditNote,
                    onMarkCompleted = onMarkCompleted,
                    onArchive = onArchiveNote,
                    onTrash = onTrashNote,
                    onRestore = onRestoreNote,
                    onDeleteForever = onDeleteNoteForever
                )
            }
        }

        // Helper hint pill in bottom-left of Infinite Canvas
        Surface(
            shape = CircleShape,
            color = MaterialTheme.colorScheme.surfaceContainerLowest.copy(alpha = 0.9f),
            shadowElevation = 4.dp,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 96.dp)
                .clickable {
                    panOffsetX = 0f
                    panOffsetY = 0f
                }
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.OpenWith,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "Drag notes or pan canvas • Tap to recenter",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun SubTabChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Surface(
        shape = CircleShape,
        color = if (selected) NoteYellowActive else MaterialTheme.colorScheme.surfaceContainerLow,
        modifier = Modifier
            .clip(CircleShape)
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Text(
            text = label,
            fontFamily = QuicksandFontFamily,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 13.sp,
            color = if (selected) NoteYellowText else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun EmptyWorkspaceState(
    subTab: WorkspaceSubTab,
    onNewNoteClick: () -> Unit,
    onRestoreStarterNotes: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = when (subTab) {
                    WorkspaceSubTab.BOARD -> Icons.Outlined.Dashboard
                    WorkspaceSubTab.ARCHIVE -> Icons.Outlined.Inventory2
                    WorkspaceSubTab.TRASH -> Icons.Outlined.Delete
                },
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(48.dp)
            )
            Text(
                text = when (subTab) {
                    WorkspaceSubTab.BOARD -> "Your Workspace Canvas is Clear"
                    WorkspaceSubTab.ARCHIVE -> "No Archived Notes Yet"
                    WorkspaceSubTab.TRASH -> "Trash is Empty"
                },
                fontFamily = QuicksandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = when (subTab) {
                    WorkspaceSubTab.BOARD -> "Add a new sticky note or restore the IdeaPad starter canvas."
                    WorkspaceSubTab.ARCHIVE -> "Archive finished boards or reference notes to keep your desktop tidy."
                    WorkspaceSubTab.TRASH -> "Notes moved to Trash will appear here."
                },
                fontFamily = QuicksandFontFamily,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (subTab == WorkspaceSubTab.BOARD) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = onNewNoteClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NoteYellowActive,
                            contentColor = NoteYellowText
                        )
                    ) {
                        Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("New Note", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = onRestoreStarterNotes) {
                        Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Starter Canvas", fontFamily = QuicksandFontFamily, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
