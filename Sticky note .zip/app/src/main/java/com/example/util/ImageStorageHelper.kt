package com.example.util

import android.content.Context
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object ImageStorageHelper {
    private const val TAG = "ImageStorageHelper"

    /**
     * Copies any content/gallery Uri into the app's internal persistent storage
     * so that it never expires and is always available offline.
     */
    fun copyUriToInternalStorage(context: Context, sourceUri: Uri): String? {
        return try {
            val imagesDir = File(context.filesDir, "note_images").apply {
                if (!exists()) mkdirs()
            }
            val destinationFile = File(imagesDir, "img_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(sourceUri)?.use { input ->
                FileOutputStream(destinationFile).use { output ->
                    input.copyTo(output)
                }
            }
            destinationFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy image URI to internal storage", e)
            sourceUri.toString()
        }
    }

    /**
     * Prepares a temporary file and FileProvider Uri for the Camera capture intent.
     */
    fun createCameraImageUri(context: Context): Pair<File, Uri>? {
        return try {
            val cameraDir = File(context.cacheDir, "camera").apply {
                if (!exists()) mkdirs()
            }
            val tempFile = File(cameraDir, "capture_${System.currentTimeMillis()}.jpg")
            val authority = "${context.packageName}.fileprovider"
            val uri = FileProvider.getUriForFile(context, authority, tempFile)
            Pair(tempFile, uri)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to create camera temp file", e)
            null
        }
    }

    /**
     * Permanently moves a captured camera file into internal storage.
     */
    fun persistCameraImage(context: Context, tempFile: File): String {
        return try {
            val imagesDir = File(context.filesDir, "note_images").apply {
                if (!exists()) mkdirs()
            }
            val destinationFile = File(imagesDir, "img_${System.currentTimeMillis()}.jpg")
            tempFile.copyTo(destinationFile, overwrite = true)
            tempFile.delete()
            destinationFile.absolutePath
        } catch (e: Exception) {
            Log.e(TAG, "Failed to persist camera image", e)
            tempFile.absolutePath
        }
    }
}
