package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Lightbulb
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import coil.compose.AsyncImage
import com.example.data.model.IdeaNote
import com.example.data.model.IdeaPadAssets
import com.example.data.repository.IdeaPadRepository
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.signOutUser
import com.example.ui.components.NoteEditorDialog
import com.example.ui.screens.CompletedScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WorkspaceScreen
import com.example.ui.theme.IdeaPadTheme
import com.example.ui.theme.NoteYellowActive
import com.example.ui.theme.NoteYellowText
import com.example.ui.theme.PrimaryFixed
import com.example.ui.theme.QuicksandFontFamily
import com.example.ui.theme.noteFontFamilyForKey
import com.example.ui.viewmodel.CompletedSortOrder
import com.example.ui.viewmodel.IdeaPadViewModel
import com.example.ui.viewmodel.TopDestination
import com.example.ui.viewmodel.UiState
import com.example.ui.viewmodel.WorkspaceSubTab
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.launch

internal fun FirebaseAuth.authStateFlow(): Flow<FirebaseUser?> = callbackFlow {
    val listener = FirebaseAuth.AuthStateListener { auth ->
        trySend(auth.currentUser)
    }
    addAuthStateListener(listener)
    awaitClose { removeAuthStateListener(listener) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppRoot()
        }
    }
}

@Composable
fun AppRoot(auth: FirebaseAuth = Firebase.auth) {
    val currentUser by auth.authStateFlow().collectAsStateWithLifecycle(initialValue = auth.currentUser)
    val user = currentUser
    var isGuestMode by rememberSaveable { mutableStateOf(false) }

    if (user == null && !isGuestMode) {
        IdeaPadTheme(themeMode = "light") {
            AuthScreen(
                onAuthSuccess = { isGuestMode = false },
                onContinueAsGuest = { isGuestMode = true }
            )
        }
    } else {
        val effectiveUid = user?.uid ?: "guest_user"
        val isGuest = (user == null)
        val viewModel: IdeaPadViewModel = viewModel(
            key = if (user != null) user.uid else "guest_session",
            factory = viewModelFactory {
                initializer {
                    val app = checkNotNull(this[APPLICATION_KEY]) {
                        "APPLICATION_KEY missing from CreationExtras"
                    }
                    val databaseId = app.getString(R.string.firestore_database_id)
                    val db = FirebaseFirestore.getInstance(databaseId)
                    IdeaPadViewModel(
                        repository = IdeaPadRepository(db, auth),
                        currentUserId = effectiveUid,
                        initialUserName = user?.displayName ?: "Guest Creative",
                        initialUserEmail = user?.email ?: "guest@ideapad.local",
                        isGuestMode = isGuest
                    )
                }
            }
        )
        IdeaPadAuthenticatedApp(
            viewModel = viewModel,
            onSignOutSession = {
                isGuestMode = false
            }
        )
    }
}

@Composable
fun IdeaPadAuthenticatedApp(
    viewModel: IdeaPadViewModel,
    onSignOutSession: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val credentialManager = remember(context) { CredentialManager.create(context) }

    val notesUiState by viewModel.notesState.collectAsStateWithLifecycle()
    val preferences by viewModel.preferencesState.collectAsStateWithLifecycle()
    val currentDestination by viewModel.currentDestination.collectAsStateWithLifecycle()
    val workspaceSubTab by viewModel.workspaceSubTab.collectAsStateWithLifecycle()
    val layoutMode by viewModel.layoutMode.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val completedSortOrder by viewModel.completedSortOrder.collectAsStateWithLifecycle()
    val statusBanner by viewModel.statusBannerMessage.collectAsStateWithLifecycle()

    var showMobileSearchBar by remember { mutableStateOf(false) }
    var editingNote by remember { mutableStateOf<IdeaNote?>(null) }
    var showCreateNoteDialog by remember { mutableStateOf(false) }

    val snackbarHostState = remember { SnackbarHostState() }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    LaunchedEffect(statusBanner) {
        statusBanner?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearStatusBanner()
        }
    }

    // Back navigation handler for full-page note editor and secondary destinations / sub-tabs
    BackHandler(
        enabled = editingNote != null ||
            showCreateNoteDialog ||
            currentDestination != TopDestination.WORKSPACE ||
            workspaceSubTab != WorkspaceSubTab.BOARD ||
            showMobileSearchBar
    ) {
        when {
            editingNote != null -> {
                editingNote = null
            }
            showCreateNoteDialog -> {
                showCreateNoteDialog = false
            }
            showMobileSearchBar -> {
                showMobileSearchBar = false
                viewModel.updateSearchQuery("")
            }
            currentDestination != TopDestination.WORKSPACE -> {
                viewModel.selectDestination(TopDestination.WORKSPACE)
            }
            workspaceSubTab != WorkspaceSubTab.BOARD -> {
                viewModel.selectWorkspaceSubTab(WorkspaceSubTab.BOARD)
            }
        }
    }

    val allNotes = (notesUiState as? UiState.Success)?.data.orEmpty()
    val filteredBySearch = remember(allNotes, searchQuery) {
        if (searchQuery.isBlank()) {
            allNotes
        } else {
            val q = searchQuery.trim().lowercase()
            allNotes.filter { note ->
                note.title.lowercase().contains(q) ||
                    note.content.lowercase().contains(q) ||
                    note.tags.any { it.lowercase().contains(q) } ||
                    note.checklistItems.any { it.lowercase().contains(q) }
            }
        }
    }

    val workspaceNotes = remember(filteredBySearch, workspaceSubTab) {
        val targetStatus = when (workspaceSubTab) {
            WorkspaceSubTab.BOARD -> "active"
            WorkspaceSubTab.ARCHIVE -> "archived"
            WorkspaceSubTab.TRASH -> "trashed"
        }
        filteredBySearch.filter { it.status == targetStatus }
    }

    val completedNotes = remember(filteredBySearch, completedSortOrder) {
        val list = filteredBySearch.filter { it.status == "completed" }
        when (completedSortOrder) {
            CompletedSortOrder.RECENT -> list
            CompletedSortOrder.TITLE -> list.sortedBy { it.title.ifBlank { it.content }.lowercase() }
            CompletedSortOrder.COLOR -> list.sortedBy { it.colorTheme }
        }
    }

    val noteFontFamily = remember(preferences.defaultTypography) {
        noteFontFamilyForKey(preferences.defaultTypography)
    }

    IdeaPadTheme(themeMode = preferences.themeMode) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpandedScreen = maxWidth >= 720.dp

            ModalNavigationDrawer(
                drawerState = drawerState,
                gesturesEnabled = !isExpandedScreen,
                drawerContent = {
                    if (!isExpandedScreen) {
                        ModalDrawerSheet(
                            drawerContainerColor = MaterialTheme.colorScheme.surface
                        ) {
                            CreativityHubSideNavContent(
                                currentDestination = currentDestination,
                                workspaceSubTab = workspaceSubTab,
                                onSelectDestination = { dest ->
                                    viewModel.selectDestination(dest)
                                    scope.launch { drawerState.close() }
                                },
                                onSelectSubTab = { sub ->
                                    viewModel.selectWorkspaceSubTab(sub)
                                    scope.launch { drawerState.close() }
                                },
                                onNewCanvasClick = {
                                    scope.launch { drawerState.close() }
                                    showCreateNoteDialog = true
                                }
                            )
                        }
                    }
                }
            ) {
                Scaffold(
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
                    topBar = {
                        IdeaPadTopBar(
                            currentDestination = currentDestination,
                            isExpandedScreen = isExpandedScreen,
                            searchQuery = searchQuery,
                            showMobileSearchBar = showMobileSearchBar,
                            onSearchQueryChange = viewModel::updateSearchQuery,
                            onToggleMobileSearch = {
                                showMobileSearchBar = !showMobileSearchBar
                                if (!showMobileSearchBar) viewModel.updateSearchQuery("")
                            },
                            onOpenDrawer = { scope.launch { drawerState.open() } },
                            onSelectDestination = viewModel::selectDestination,
                            onClearCompleted = { viewModel.clearAllByStatus("completed") },
                            onSyncNow = viewModel::syncNow
                        )
                    },
                    bottomBar = {
                        if (!isExpandedScreen) {
                            IdeaPadMobileBottomNav(
                                currentDestination = currentDestination,
                                workspaceSubTab = workspaceSubTab,
                                onSelectDestination = viewModel::selectDestination,
                                onSelectSubTab = viewModel::selectWorkspaceSubTab
                            )
                        }
                    },
                    floatingActionButton = {
                        if (currentDestination == TopDestination.WORKSPACE &&
                            workspaceSubTab == WorkspaceSubTab.BOARD
                        ) {
                            FloatingActionButton(
                                onClick = { showCreateNoteDialog = true },
                                shape = CircleShape,
                                containerColor = PrimaryFixed,
                                contentColor = NoteYellowText,
                                modifier = Modifier
                                    .padding(bottom = if (isExpandedScreen) 16.dp else 4.dp)
                                    .size(64.dp)
                                    .testTag("add_note_fab")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Add,
                                    contentDescription = "New Note",
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        // Permanent Creativity Hub Sidebar on Tablet / Desktop (matching Images 3, 5, 6)
                        if (isExpandedScreen) {
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceContainerLow,
                                tonalElevation = 1.dp,
                                modifier = Modifier
                                    .width(256.dp)
                                    .fillMaxHeight()
                            ) {
                                CreativityHubSideNavContent(
                                    currentDestination = currentDestination,
                                    workspaceSubTab = workspaceSubTab,
                                    onSelectDestination = viewModel::selectDestination,
                                    onSelectSubTab = viewModel::selectWorkspaceSubTab,
                                    onNewCanvasClick = { showCreateNoteDialog = true }
                                )
                            }
                        }

                        // Main Content Pane
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        ) {
                            AnimatedContent(
                            targetState = currentDestination,
                            transitionSpec = {
                                if (preferences.reduceMotion) {
                                    fadeIn(animationSpec = tween(50)) togetherWith fadeOut(animationSpec = tween(50))
                                } else {
                                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(140))
                                }
                            },
                            label = "top_destination_anim",
                            modifier = Modifier.fillMaxSize()
                        ) { destination ->
                            when (destination) {
                                TopDestination.SETTINGS -> {
                                    SettingsScreen(
                                        preferences = preferences,
                                        allNotes = allNotes,
                                        isExpandedScreen = isExpandedScreen,
                                        onUpdatePreferences = viewModel::updatePreferences,
                                        onSyncNow = viewModel::syncNow,
                                        onRestoreStarterNotes = viewModel::restoreStarterWorkspace,
                                        onSignOut = {
                                            if (viewModel.isGuestMode) {
                                                onSignOutSession()
                                            } else {
                                                signOutUser(
                                                    credentialManager = credentialManager,
                                                    onSignOutComplete = {
                                                        onSignOutSession()
                                                    },
                                                    scope = scope
                                                )
                                            }
                                        }
                                    )
                                }
                                TopDestination.WORKSPACE -> {
                                    when (val state = notesUiState) {
                                        is UiState.Loading -> {
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                        is UiState.Error -> {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(32.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Surface(
                                                    shape = CircleShape,
                                                    color = MaterialTheme.colorScheme.errorContainer,
                                                    modifier = Modifier.size(56.dp)
                                                ) {
                                                    Box(contentAlignment = Alignment.Center) {
                                                        Icon(
                                                            imageVector = Icons.Filled.Close,
                                                            contentDescription = null,
                                                            tint = MaterialTheme.colorScheme.onErrorContainer,
                                                            modifier = Modifier.size(28.dp)
                                                        )
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(16.dp))
                                                Text(
                                                    text = "Could not sync Workspace",
                                                    fontFamily = QuicksandFontFamily,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 20.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = state.message,
                                                    fontFamily = QuicksandFontFamily,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.height(20.dp))
                                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                                    Button(
                                                        onClick = { viewModel.restoreStarterWorkspace() },
                                                        colors = ButtonDefaults.buttonColors(
                                                            containerColor = NoteYellowActive,
                                                            contentColor = NoteYellowText
                                                        )
                                                    ) {
                                                        Text(
                                                            text = "Load Starter Notes",
                                                            fontFamily = QuicksandFontFamily,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                    Button(
                                                        onClick = { viewModel.syncNow() }
                                                    ) {
                                                        Text("Retry Sync")
                                                    }
                                                }
                                            }
                                        }
                                        is UiState.Success -> {
                                            WorkspaceScreen(
                                                notes = workspaceNotes,
                                                subTab = workspaceSubTab,
                                                layoutMode = layoutMode,
                                                preferences = preferences,
                                                noteFontFamily = noteFontFamily,
                                                isExpandedScreen = isExpandedScreen,
                                                onSubTabChange = viewModel::selectWorkspaceSubTab,
                                                onToggleLayoutMode = viewModel::toggleWorkspaceLayoutMode,
                                                onNewNoteClick = { showCreateNoteDialog = true },
                                                onEditNote = { editingNote = it },
                                                onMarkCompleted = { viewModel.updateNoteStatus(it, "completed") },
                                                onArchiveNote = { viewModel.updateNoteStatus(it, "archived") },
                                                onTrashNote = { viewModel.updateNoteStatus(it, "trashed") },
                                                onRestoreNote = { viewModel.updateNoteStatus(it, "active") },
                                                onDeleteNoteForever = viewModel::deleteNoteForever,
                                                onUpdateCanvasPosition = viewModel::updateNoteCanvasPosition,
                                                onEmptyTrash = { viewModel.clearAllByStatus("trashed") },
                                                onRestoreStarterNotes = viewModel::restoreStarterWorkspace
                                            )
                                        }
                                    }
                                }
                                TopDestination.COMPLETED -> {
                                    when (val state = notesUiState) {
                                        is UiState.Loading -> {
                                            Box(
                                                modifier = Modifier.fillMaxSize(),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                        is UiState.Error -> {
                                            Column(
                                                modifier = Modifier
                                                    .fillMaxSize()
                                                    .padding(32.dp),
                                                horizontalAlignment = Alignment.CenterHorizontally,
                                                verticalArrangement = Arrangement.Center
                                            ) {
                                                Text(
                                                    text = "Completed notes unavailable",
                                                    fontFamily = QuicksandFontFamily,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 20.sp,
                                                    color = MaterialTheme.colorScheme.onSurface
                                                )
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = state.message,
                                                    fontFamily = QuicksandFontFamily,
                                                    fontSize = 14.sp,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Spacer(modifier = Modifier.height(16.dp))
                                                Button(onClick = { viewModel.restoreStarterWorkspace() }) {
                                                    Text("Load Starter Notes")
                                                }
                                            }
                                        }
                                        is UiState.Success -> {
                                            CompletedScreen(
                                                completedNotes = completedNotes,
                                                sortOrder = completedSortOrder,
                                                noteFontFamily = noteFontFamily,
                                                isExpandedScreen = isExpandedScreen,
                                                onCycleSortOrder = viewModel::cycleCompletedSortOrder,
                                                onToggleRestoreNote = { viewModel.updateNoteStatus(it, "active") },
                                                onEditNote = { editingNote = it },
                                                onDeleteNote = viewModel::deleteNoteForever,
                                                onRestoreStarterNotes = viewModel::restoreStarterWorkspace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        AnimatedVisibility(
            visible = showCreateNoteDialog,
            enter = fadeIn(animationSpec = tween(200)),
            exit = fadeOut(animationSpec = tween(150))
        ) {
            NoteEditorDialog(
                initialNote = null,
                defaultColor = preferences.defaultNoteColor,
                noteFontFamily = noteFontFamily,
                onDismiss = { showCreateNoteDialog = false },
                onSave = { title, content, noteType, colorTheme, tags, checklist, imageUrl, codeSnippet ->
                    viewModel.createNote(
                        title = title,
                        content = content,
                        noteType = noteType,
                        colorTheme = colorTheme,
                        tagsInput = tags,
                        checklistInput = checklist,
                        imageUrl = imageUrl,
                        codeSnippet = codeSnippet
                    )
                }
            )
        }

        AnimatedVisibility(
            visible = editingNote != null,
            enter = fadeIn(animationSpec = tween(200)),
            exit = fadeOut(animationSpec = tween(150))
        ) {
            editingNote?.let { targetNote ->
                NoteEditorDialog(
                    initialNote = targetNote,
                    defaultColor = preferences.defaultNoteColor,
                    noteFontFamily = noteFontFamily,
                    onDismiss = { editingNote = null },
                    onSave = { title, content, noteType, colorTheme, tags, checklist, imageUrl, codeSnippet ->
                        viewModel.updateExistingNote(
                            existing = targetNote,
                            title = title,
                            content = content,
                            noteType = noteType,
                            colorTheme = colorTheme,
                            tagsInput = tags,
                            checklistInput = checklist,
                            imageUrl = imageUrl,
                            codeSnippet = codeSnippet
                        )
                    },
                    onChangeStatus = { newStatus ->
                        viewModel.updateNoteStatus(targetNote, newStatus)
                    },
                    onDelete = {
                        if (targetNote.status == "trashed") {
                            viewModel.deleteNoteForever(targetNote.id)
                        } else {
                            viewModel.updateNoteStatus(targetNote, "trashed")
                        }
                    }
                )
            }
        }
    }
}
}

@Composable
private fun IdeaPadTopBar(
    currentDestination: TopDestination,
    isExpandedScreen: Boolean,
    searchQuery: String,
    showMobileSearchBar: Boolean,
    onSearchQueryChange: (String) -> Unit,
    onToggleMobileSearch: () -> Unit,
    onOpenDrawer: () -> Unit,
    onSelectDestination: (TopDestination) -> Unit,
    onClearCompleted: () -> Unit,
    onSyncNow: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.background.copy(alpha = 0.94f),
        tonalElevation = if (isExpandedScreen) 2.dp else 0.dp,
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            if (isExpandedScreen) {
                // Desktop / Tablet TopNavBar (matching Images 3, 5, 6)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(64.dp)
                        .padding(horizontal = 32.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(24.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = "IdeaPad",
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Search pill bar
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.7f),
                            modifier = Modifier
                                .width(320.dp)
                                .height(40.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = 14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = "Search ideas",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                                BasicTextField(
                                    value = searchQuery,
                                    onValueChange = onSearchQueryChange,
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        fontFamily = QuicksandFontFamily,
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    ),
                                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                    decorationBox = { innerTextField ->
                                        if (searchQuery.isEmpty()) {
                                            Text(
                                                text = "Search ideas...",
                                                fontFamily = QuicksandFontFamily,
                                                fontSize = 14.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        innerTextField()
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("desktop_search_input")
                                )
                                if (searchQuery.isNotEmpty()) {
                                    Icon(
                                        imageVector = Icons.Filled.Close,
                                        contentDescription = "Clear search",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clickable { onSearchQueryChange("") }
                                    )
                                }
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(20.dp)
                    ) {
                        TopNavTabLink(
                            label = "Workspace",
                            selected = currentDestination == TopDestination.WORKSPACE,
                            onClick = { onSelectDestination(TopDestination.WORKSPACE) }
                        )
                        TopNavTabLink(
                            label = "Completed",
                            selected = currentDestination == TopDestination.COMPLETED,
                            onClick = { onSelectDestination(TopDestination.COMPLETED) }
                        )
                        TopNavTabLink(
                            label = "Settings",
                            selected = currentDestination == TopDestination.SETTINGS,
                            onClick = { onSelectDestination(TopDestination.SETTINGS) }
                        )

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(onClick = onSyncNow) {
                                Icon(
                                    imageVector = Icons.Filled.CloudDone,
                                    contentDescription = "Cloud Synced",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onSelectDestination(TopDestination.SETTINGS) }) {
                                Icon(
                                    imageVector = Icons.Filled.AccountCircle,
                                    contentDescription = "Account Settings",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            } else {
                // Mobile Top Header (matching Images 1, 2, 4)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    if (currentDestination == TopDestination.SETTINGS) {
                        Text(
                            text = "Settings",
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(start = 4.dp)
                        )
                        IconButton(onClick = onSyncNow) {
                            Icon(
                                imageVector = Icons.Filled.CloudDone,
                                contentDescription = "Sync status",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    } else if (currentDestination == TopDestination.COMPLETED) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            IconButton(
                                onClick = onOpenDrawer,
                                modifier = Modifier.testTag("open_drawer_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Menu,
                                    contentDescription = "Menu",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            Text(
                                text = "IdeaPad",
                                fontFamily = QuicksandFontFamily,
                                fontWeight = FontWeight.Bold,
                                fontSize = 24.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        IconButton(
                            onClick = onClearCompleted,
                            modifier = Modifier.testTag("clear_completed_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DeleteSweep,
                                contentDescription = "Clear All Completed",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    } else {
                        // Mobile Workspace Header: Menu on left, centered IdeaPad title, Search on right (Image 4)
                        IconButton(
                            onClick = onOpenDrawer,
                            modifier = Modifier.testTag("open_drawer_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Menu,
                                contentDescription = "Menu",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Text(
                            text = "IdeaPad",
                            fontFamily = QuicksandFontFamily,
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(
                            onClick = onToggleMobileSearch,
                            modifier = Modifier.testTag("mobile_search_button")
                        ) {
                            Icon(
                                imageVector = if (showMobileSearchBar) Icons.Filled.Close else Icons.Filled.Search,
                                contentDescription = "Search",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                AnimatedVisibility(visible = showMobileSearchBar && !isExpandedScreen) {
                    Surface(
                        shape = CircleShape,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            BasicTextField(
                                value = searchQuery,
                                onValueChange = onSearchQueryChange,
                                singleLine = true,
                                textStyle = TextStyle(
                                    fontFamily = QuicksandFontFamily,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                ),
                                cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                                decorationBox = { innerTextField ->
                                    if (searchQuery.isEmpty()) {
                                        Text(
                                            text = "Search ideas, tags, checklists...",
                                            fontFamily = QuicksandFontFamily,
                                            fontSize = 14.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    innerTextField()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("mobile_search_input")
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TopNavTabLink(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontFamily = QuicksandFontFamily,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            fontSize = 18.sp,
            color = if (selected) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            }
        )
        Spacer(modifier = Modifier.height(3.dp))
        Box(
            modifier = Modifier
                .width(if (selected) 56.dp else 0.dp)
                .height(2.5.dp)
                .background(
                    if (selected) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent,
                    RoundedCornerShape(2.dp)
                )
        )
    }
}

@Composable
private fun CreativityHubSideNavContent(
    currentDestination: TopDestination,
    workspaceSubTab: WorkspaceSubTab,
    onSelectDestination: (TopDestination) -> Unit,
    onSelectSubTab: (WorkspaceSubTab) -> Unit,
    onNewCanvasClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .padding(20.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            // Creativity Hub Header with Avatar (matching Images 3, 5, 6)
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.padding(vertical = 8.dp)
            ) {
                AsyncImage(
                    model = IdeaPadAssets.STUDIO_AVATAR_IMAGE,
                    contentDescription = "Creativity Hub Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(NoteYellowActive)
                )
                Column {
                    Text(
                        text = "Creativity Hub",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Uninhibited Flow",
                        fontFamily = QuicksandFontFamily,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Button(
                onClick = onNewCanvasClick,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = NoteYellowActive,
                    contentColor = NoteYellowText
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("drawer_new_canvas_button")
            ) {
                Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "New Canvas",
                    fontFamily = QuicksandFontFamily,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }

            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                SideNavItem(
                    label = "Board",
                    icon = if (currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.BOARD) {
                        Icons.Filled.Dashboard
                    } else {
                        Icons.Outlined.Dashboard
                    },
                    selected = currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.BOARD,
                    onClick = { onSelectSubTab(WorkspaceSubTab.BOARD) }
                )
                SideNavItem(
                    label = "Archive",
                    icon = if (currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.ARCHIVE) {
                        Icons.Filled.Inventory2
                    } else {
                        Icons.Outlined.Inventory2
                    },
                    selected = currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.ARCHIVE,
                    onClick = { onSelectSubTab(WorkspaceSubTab.ARCHIVE) }
                )
                SideNavItem(
                    label = "Trash",
                    icon = if (currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.TRASH) {
                        Icons.Filled.Delete
                    } else {
                        Icons.Outlined.Delete
                    },
                    selected = currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.TRASH,
                    onClick = { onSelectSubTab(WorkspaceSubTab.TRASH) }
                )
                SideNavItem(
                    label = "Completed",
                    icon = if (currentDestination == TopDestination.COMPLETED) {
                        Icons.Filled.CheckCircle
                    } else {
                        Icons.Outlined.CheckCircle
                    },
                    selected = currentDestination == TopDestination.COMPLETED,
                    onClick = { onSelectDestination(TopDestination.COMPLETED) }
                )
                SideNavItem(
                    label = "Settings",
                    icon = if (currentDestination == TopDestination.SETTINGS) {
                        Icons.Filled.Settings
                    } else {
                        Icons.Outlined.Settings
                    },
                    selected = currentDestination == TopDestination.SETTINGS,
                    onClick = { onSelectDestination(TopDestination.SETTINGS) }
                )
            }
        }

        Button(
            onClick = onNewCanvasClick,
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
        ) {
            Icon(Icons.Filled.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "New Canvas",
                fontFamily = QuicksandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun SideNavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (selected) NoteYellowActive else androidx.compose.ui.graphics.Color.Transparent,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) NoteYellowText else MaterialTheme.colorScheme.onSurfaceVariant
            )
            Text(
                text = label,
                fontFamily = QuicksandFontFamily,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 16.sp,
                color = if (selected) NoteYellowText else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun IdeaPadMobileBottomNav(
    currentDestination: TopDestination,
    workspaceSubTab: WorkspaceSubTab,
    onSelectDestination: (TopDestination) -> Unit,
    onSelectSubTab: (WorkspaceSubTab) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
        shadowElevation = 10.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Tab 1: Workspace (Lightbulb / Grid icon as shown in Images 1, 2, 4)
            BottomNavPillItem(
                label = "Workspace",
                icon = if (currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.BOARD) {
                    Icons.Filled.Lightbulb
                } else {
                    Icons.Outlined.Lightbulb
                },
                selected = currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.BOARD,
                onClick = { onSelectSubTab(WorkspaceSubTab.BOARD) },
                testTag = "nav_workspace"
            )

            // Tab 2: Completed ("Done & Dusted", Image 2)
            BottomNavPillItem(
                label = "Completed",
                icon = if (currentDestination == TopDestination.COMPLETED) {
                    Icons.Filled.CheckCircle
                } else {
                    Icons.Outlined.CheckCircle
                },
                selected = currentDestination == TopDestination.COMPLETED,
                onClick = { onSelectDestination(TopDestination.COMPLETED) },
                testTag = "nav_completed"
            )

            // Tab 3: Archive (shown in Images 1 & 4)
            BottomNavPillItem(
                label = "Archive",
                icon = if (currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.ARCHIVE) {
                    Icons.Filled.Inventory2
                } else {
                    Icons.Outlined.Inventory2
                },
                selected = currentDestination == TopDestination.WORKSPACE && workspaceSubTab == WorkspaceSubTab.ARCHIVE,
                onClick = { onSelectSubTab(WorkspaceSubTab.ARCHIVE) },
                testTag = "nav_archive"
            )

            // Tab 4: Settings (shown in Images 1 & 2)
            BottomNavPillItem(
                label = "Settings",
                icon = if (currentDestination == TopDestination.SETTINGS) {
                    Icons.Filled.Settings
                } else {
                    Icons.Outlined.Settings
                },
                selected = currentDestination == TopDestination.SETTINGS,
                onClick = { onSelectDestination(TopDestination.SETTINGS) },
                testTag = "nav_settings"
            )
        }
    }
}

@Composable
private fun BottomNavPillItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = if (selected) NoteYellowActive else androidx.compose.ui.graphics.Color.Transparent,
        modifier = Modifier
            .clip(RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag(testTag)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) NoteYellowText else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = label,
                fontFamily = QuicksandFontFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                letterSpacing = 0.4.sp,
                color = if (selected) NoteYellowText else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
