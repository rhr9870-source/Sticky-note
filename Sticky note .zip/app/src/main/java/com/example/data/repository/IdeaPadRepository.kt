package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.data.model.IdeaNote
import com.example.data.model.IdeaPadAssets
import com.example.data.model.UserPreferences
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import java.util.UUID
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class IdeaPadRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(): String {
        return auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
    }

    fun observeNotes(userId: String? = null): Flow<List<IdeaNote>> = flow {
        val targetUid = userId ?: auth.currentUser?.uid ?: "unauthenticated"
        val path = "users/$targetUid/notes"
        emitAll(
            db.collection("users").document(targetUid).collection("notes")
                .snapshots()
                .map { snapshot ->
                    snapshot.documents.mapNotNull { doc ->
                        doc.toObject(
                            IdeaNote::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.LIST, path)
                    throw error
                }
        )
    }

    fun observePreferences(userId: String? = null): Flow<UserPreferences?> = flow {
        val targetUid = userId ?: auth.currentUser?.uid ?: "unauthenticated"
        val path = "users/$targetUid/settings/preferences"
        emitAll(
            db.collection("users").document(targetUid)
                .collection("settings").document("preferences")
                .snapshots()
                .map { snapshot ->
                    if (snapshot.exists()) {
                        snapshot.toObject(
                            UserPreferences::class.java,
                            DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                        )
                    } else {
                        null
                    }
                }
                .catch { error ->
                    if (error is Exception) handleFirestoreError(error, OperationType.GET, path)
                    throw error
                }
        )
    }

    suspend fun getUserNotes(userId: String? = null): Result<List<IdeaNote>> = runCatching {
        val targetUid = userId ?: requireUserId()
        val path = "users/$targetUid/notes"
        try {
            val snapshot = db.collection("users").document(targetUid).collection("notes")
                .get()
                .await()
            snapshot.documents.mapNotNull { doc ->
                doc.toObject(
                    IdeaNote::class.java,
                    DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
                )
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.LIST, path)
            throw e
        }
    }

    suspend fun getNoteById(noteId: String, ownerUserId: String? = null): Result<IdeaNote?> = runCatching {
        val targetUid = ownerUserId ?: requireUserId()
        val path = "users/$targetUid/notes/$noteId"
        try {
            val snapshot = db.collection("users").document(targetUid)
                .collection("notes").document(noteId)
                .get()
                .await()
            snapshot.toObject(
                IdeaNote::class.java,
                DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            )
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, path)
            throw e
        }
    }

    suspend fun createNote(note: IdeaNote): Result<String> = runCatching {
        val uid = requireUserId()
        val noteId = note.id.ifBlank { "note_${UUID.randomUUID().toString().replace("-", "").take(16)}" }
        val docRef = db.collection("users").document(uid).collection("notes").document(noteId)
        try {
            val payload = note.copy(
                id = noteId,
                userId = uid,
                createdAt = null,
                updatedAt = null
            )
            docRef.set(payload).await()
            noteId
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docRef.path)
            throw e
        }
    }

    suspend fun updateNote(note: IdeaNote): Result<Unit> = runCatching {
        val uid = requireUserId()
        require(note.id.isNotBlank()) { "Note ID must not be blank for update" }
        val docRef = db.collection("users").document(uid).collection("notes").document(note.id)
        try {
            val existingCreatedAt = note.createdAt
            if (existingCreatedAt != null) {
                docRef.set(note.copy(userId = uid, updatedAt = null)).await()
            } else {
                val updates = mapOf(
                    "title" to note.title,
                    "content" to note.content,
                    "noteType" to note.noteType,
                    "colorTheme" to note.colorTheme,
                    "status" to note.status,
                    "tags" to note.tags,
                    "checklistItems" to note.checklistItems,
                    "imageUrl" to note.imageUrl,
                    "codeSnippet" to note.codeSnippet,
                    "canvasX" to note.canvasX,
                    "canvasY" to note.canvasY,
                    "rotationDeg" to note.rotationDeg,
                    "dateLabel" to note.dateLabel,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docRef.path)
            throw e
        }
    }

    suspend fun deleteNote(noteId: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("notes").document(noteId)
        try {
            docRef.delete().await()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docRef.path)
            throw e
        }
    }

    suspend fun clearNotesByStatus(status: String): Result<Unit> = runCatching {
        val uid = requireUserId()
        val notes = getUserNotes(uid).getOrThrow().filter { it.status == status }
        for (note in notes) {
            deleteNote(note.id).getOrThrow()
        }
    }

    suspend fun savePreferences(prefs: UserPreferences): Result<Unit> = runCatching {
        val uid = requireUserId()
        val docRef = db.collection("users").document(uid).collection("settings").document("preferences")
        try {
            val snap = docRef.get().await()
            if (snap.exists()) {
                val updates = mapOf(
                    "displayName" to prefs.displayName.ifBlank { "Creative Thinker" }.take(80),
                    "email" to prefs.email.take(120),
                    "themeMode" to prefs.themeMode,
                    "reduceMotion" to prefs.reduceMotion,
                    "defaultNoteColor" to prefs.defaultNoteColor,
                    "defaultTypography" to prefs.defaultTypography,
                    "canvasGridEnabled" to prefs.canvasGridEnabled,
                    "snapToGrid" to prefs.snapToGrid,
                    "gridDensity" to prefs.gridDensity.coerceIn(1L, 3L),
                    "lastSyncedLabel" to prefs.lastSyncedLabel.take(60),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                docRef.update(updates).await()
            } else {
                val newPrefs = prefs.copy(
                    id = "preferences",
                    userId = uid,
                    displayName = prefs.displayName.ifBlank { "Creative Thinker" }.take(80),
                    email = prefs.email.take(120),
                    gridDensity = prefs.gridDensity.coerceIn(1L, 3L),
                    createdAt = null,
                    updatedAt = null
                )
                docRef.set(newPrefs).await()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, docRef.path)
            throw e
        }
    }

    suspend fun seedInitialWorkspaceIfEmpty(
        defaultDisplayName: String = "Creative Thinker",
        defaultEmail: String = "hello@ideapad.app"
    ): Result<Boolean> = runCatching {
        val uid = requireUserId()
        val existingNotes = getUserNotes(uid).getOrThrow()
        val prefDoc = db.collection("users").document(uid).collection("settings").document("preferences").get().await()
        if (!prefDoc.exists()) {
            savePreferences(
                UserPreferences(
                    userId = uid,
                    displayName = defaultDisplayName.ifBlank { "Creative Thinker" },
                    email = defaultEmail.ifBlank { "hello@ideapad.app" }
                )
            ).getOrThrow()
        }
        if (existingNotes.isEmpty()) {
            val initialNotes = IdeaPadAssets.buildInitialNotes(uid)
            for (note in initialNotes) {
                createNote(note).getOrThrow()
            }
            true
        } else {
            false
        }
    }

    suspend fun resetToStarterNotes(): Result<Unit> = runCatching {
        val uid = requireUserId()
        val initialNotes = IdeaPadAssets.buildInitialNotes(uid)
        for (note in initialNotes) {
            val docRef = db.collection("users").document(uid).collection("notes").document(note.id)
            val snap = docRef.get().await()
            if (!snap.exists()) {
                createNote(note).getOrThrow()
            }
        }
    }
}
