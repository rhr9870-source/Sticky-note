package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class IdeaNote(
    @DocumentId val id: String = "",
    val userId: String = "",
    val title: String = "",
    val content: String = "",
    val noteType: String = "text", // "text", "checklist", "image", "code"
    val colorTheme: String = "yellow", // "yellow", "pink", "green", "blue", "purple", "neutral", "coral"
    val status: String = "active", // "active", "completed", "archived", "trashed"
    val tags: List<String> = emptyList(),
    val checklistItems: List<String> = emptyList(),
    val imageUrl: String = "",
    val codeSnippet: String = "",
    val canvasX: Long = 100L,
    val canvasY: Long = 100L,
    val rotationDeg: Long = 0L,
    val dateLabel: String = "Today",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserPreferences(
    @DocumentId val id: String = "preferences",
    val userId: String = "",
    val displayName: String = "Creative Thinker",
    val email: String = "hello@ideapad.app",
    val themeMode: String = "light", // "light", "dark", "auto"
    val reduceMotion: Boolean = false,
    val defaultNoteColor: String = "yellow", // "yellow", "pink", "green", "neutral"
    val defaultTypography: String = "bricolage", // "bricolage", "quicksand", "mono"
    val canvasGridEnabled: Boolean = true,
    val snapToGrid: Boolean = true,
    val gridDensity: Long = 2L, // 1 = Loose, 2 = Medium, 3 = Tight
    val lastSyncedLabel: String = "Just now",
    @ServerTimestamp val createdAt: Timestamp? = null,
    @ServerTimestamp val updatedAt: Timestamp? = null
)

object IdeaPadAssets {
    const val MOODBOARD_DESK_IMAGE =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBg528gVYKvy0qV6XOVJ0ZjovbbvF5qbOL15O3L37Wv5KKMoOeWGqCbVgwp4IxmOhjLDdZ8KsWgwq6a0bfipX2q93PRuNX4jr_y6PP3viCYunuCfjhuvSRrrMxpf4G6JkIYLwwJ275o-tf4KKsgx5GcsKYC47Jw-YHtJEOLFJFdW8XHpeB88A47zfXMYOGAa_wqEZcYotUxr4kQBfJqQDzAn2fNvOVB3Srz_6nPSFWUyXQzW1SfMtjpET2bqB9rOtOWOS559iohLR-O"

    const val INSPIRATION_WALL_IMAGE =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuA-HOVwotdKZr3c2mwacCCA8qwvNrq_AEWIr0sBoAF_RnyM4wUZL1uBkiH1CYy-EE91U2m2k7q_EH087CvL1eOb6CoHmZj0V-fC45hYA-J5OICDHPzG-tdmLir6YtAMNxftbYMJUqEqMk_JRU5Iv4KjnSYAeyMF-RuQfqkqT1kBwDwPLLVUVsZzuq3-F5UIqnPGvDuXoqyTTTcXsBD_aTxGTacYeFarSaxRBFxgYkmLsdJnOezgWE3UwqGkY5PPvsI7_tXaCzn4v06h"

    const val PRESENTATION_DECK_IMAGE =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuB5pWApsRsWDTCo2_ISPoSy8aIENhqLZuEH1dcr6oHTOq39T6-8Lgp3n9DJbhM0ztzZkQLPtWpJZNsPeVaVa21Fa6rNjLtAfgI2JPsEEtSr8mW0ApHF_YkDlLGPObhBLnEOYFi26EBGGDF0tWmGZPP_rZUMYXq-Ol0N_KIv6sjUJBHr6GZYqWaFccShnmfY8vce04pvVAoGfMqw0LXY9jbwQIfsF7GaAvQgj7smtmGv92OlZf0Aoh-neLg31Vs8omX8tm75BoFxNRsS"

    const val STUDIO_AVATAR_IMAGE =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuAV8kumlFb8OE1b7vjHFYdYXo16kTFvsiO1tnQuPub_1rl_2Pfl-opRscfBYzH8Ki2_3EJntc3vuiCUlD18pdZkFr4c5Vy1E9aeKJBEL0jwwM9e1DshfeWslfiTf_9b85N-J7JUUNrhZUwYZ-wPe0-nGTv0Ax7mpBfYs2ZRoKTgH3cXXpKYML66Rf1rR9ObhQQ3kyTgSeH6-91bDyjkzJBjhX4GrZMLqeMbjGidoP8PSqfYD7Yi7aMNld_Dxis1Wst6JJ3d_lci2bvX"

    const val PASTEL_AVATAR_IMAGE =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuBcsttS9WDap78-fQVsBwqpkHYq_pszLurB-Pa5z1as7DDPSXuMgkHa6hTDTcjwRtWNmln6pgMgfBPyucQ27SwBOkGiSNwYRGDUqFGu0yDulqYG1Qmlr17TNQ1MqaS6NRVajeyqVQVFeNSKR0nQ3qGvPkjAfrUvGYoGP8Hdq5uZ9oUTJLluGZhxLQZxcjPetwKCpINWOL_TnH7GpfOBD-mrqFUvZ1EbBLoLG1wlEsG2bPQomjvvvhiAOlr_156RoiquaKGS6U8xaxJU"

    const val PROFILE_AVATAR_IMAGE =
        "https://lh3.googleusercontent.com/aida-public/AB6AXuDxrJh8qqFHGZAuZDbeE9vgws-6BfPXDd1qgdLrWVl2SXLycWs4MKcTJe0g1ABFE81_zDvHmWQMh4Ldar6VolBB_ebk1LnOOxawmRodPqmMKoJ0V-hwa_6Hn6M0wcPEzu_cAP7pozDGwWo6470wN82qkriPnjdiUoGraR4wu9wpm73NS2Jv1jyuANOUMDXeFAel-knsFwWTatEjF3bEsexTY0fXh-2Pya7FM0lh9q7C_p2pLKAkeEK8uqOLzj_ubiZiBG5IqPjlPkws"

    fun buildInitialNotes(userId: String): List<IdeaNote> = listOf(
        // Active Workspace Notes (from Mobile & Desktop Workspace screens)
        IdeaNote(
            id = "seed_ws_1",
            userId = userId,
            title = "Landing Page Hero Redesign",
            content = "Redesign the landing page hero section. Needs to feel more organic and less structured. Maybe incorporate some floating 3D elements or soft gradients?",
            noteType = "text",
            colorTheme = "yellow",
            status = "active",
            tags = listOf("Design", "Urgent"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 40L,
            canvasY = 40L,
            rotationDeg = -1L,
            dateLabel = "Today"
        ),
        IdeaNote(
            id = "seed_ws_2",
            userId = userId,
            title = "Studio Pantry Run",
            content = "Buy more oat milk and coffee beans.",
            noteType = "text",
            colorTheme = "pink",
            status = "active",
            tags = listOf("Shopping"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 420L,
            canvasY = 310L,
            rotationDeg = 1L,
            dateLabel = "Today"
        ),
        IdeaNote(
            id = "seed_ws_3",
            userId = userId,
            title = "Q3 Goals",
            content = "Key product milestones for the upcoming quarter release.",
            noteType = "checklist",
            colorTheme = "green",
            status = "active",
            tags = listOf("Planning", "Active"),
            checklistItems = listOf(
                "Launch new feature set",
                "Update documentation",
                "User testing round 2",
                "Refine animation curves"
            ),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 720L,
            canvasY = 30L,
            rotationDeg = -1L,
            dateLabel = "Today"
        ),
        IdeaNote(
            id = "seed_ws_4",
            userId = userId,
            title = "Workspace Tactile Moodboard",
            content = "Moodboard inspiration for the new workspace tactile feel.",
            noteType = "image",
            colorTheme = "neutral",
            status = "active",
            tags = listOf("Moodboard"),
            checklistItems = emptyList(),
            imageUrl = MOODBOARD_DESK_IMAGE,
            codeSnippet = "",
            canvasX = 80L,
            canvasY = 330L,
            rotationDeg = 0L,
            dateLabel = "Today"
        ),
        IdeaNote(
            id = "seed_ws_5",
            userId = userId,
            title = "Dark Mode Toggle Hook",
            content = "Remember to implement the dark mode toggle hook in the global state.",
            noteType = "code",
            colorTheme = "neutral",
            status = "active",
            tags = listOf("Dev"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "const toggleTheme = () => {\n  document.body.classList.toggle('dark');\n};",
            canvasX = 400L,
            canvasY = 110L,
            rotationDeg = 2L,
            dateLabel = "Today"
        ),
        IdeaNote(
            id = "seed_ws_6",
            userId = userId,
            title = "Idea: Ambient soundscapes tied to focus modes.",
            content = "Check user feedback on the new masonry layout and ambient focus audio.",
            noteType = "text",
            colorTheme = "yellow",
            status = "active",
            tags = listOf("Feature", "Research"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 760L,
            canvasY = 320L,
            rotationDeg = 1L,
            dateLabel = "Today"
        ),

        // Completed ("Done & Dusted") Notes (from Mobile & Desktop Completed screens)
        IdeaNote(
            id = "seed_done_1",
            userId = userId,
            title = "Q3 Marketing Brainstorm",
            content = "Draft initial concepts for the fall campaign. Focus on the \"Soft Minimalism\" angle.",
            noteType = "checklist",
            colorTheme = "yellow",
            status = "completed",
            tags = listOf("WORK", "PLANNING"),
            checklistItems = listOf(
                "Finalize moodboard for autumn campaign",
                "Draft social media copy",
                "Review budget allocation"
            ),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 60L,
            canvasY = 60L,
            rotationDeg = 0L,
            dateLabel = "Oct 12, 2023"
        ),
        IdeaNote(
            id = "seed_done_2",
            userId = userId,
            title = "App Redesign Concept",
            content = "Explore softer shadows and a more tactile feel for the interface. Consider using a masonry layout for the dashboard to break the rigid grid look.",
            noteType = "text",
            colorTheme = "blue",
            status = "completed",
            tags = listOf("DESIGN"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 360L,
            canvasY = 60L,
            rotationDeg = 0L,
            dateLabel = "Oct 11, 2023"
        ),
        IdeaNote(
            id = "seed_done_3",
            userId = userId,
            title = "Coffee Beans Restock",
            content = "Buy coffee beans (light roast)",
            noteType = "text",
            colorTheme = "pink",
            status = "completed",
            tags = listOf("PERSONAL"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 660L,
            canvasY = 60L,
            rotationDeg = 0L,
            dateLabel = "Oct 10, 2023"
        ),
        IdeaNote(
            id = "seed_done_4",
            userId = userId,
            title = "Meeting Notes: Project Alpha",
            content = "Client is happy with the initial wireframes. They requested slightly larger typography for accessibility.\n\nNext steps: Refine color palette and create high-fidelity mockups by Thursday.",
            noteType = "text",
            colorTheme = "green",
            status = "completed",
            tags = listOf("MEETING", "ALPHA"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 60L,
            canvasY = 320L,
            rotationDeg = 0L,
            dateLabel = "Oct 09, 2023"
        ),
        IdeaNote(
            id = "seed_done_5",
            userId = userId,
            title = "Inspiration Board",
            content = "Minimalist home office setup and tactile sticky note wall arrangement.",
            noteType = "image",
            colorTheme = "purple",
            status = "completed",
            tags = listOf("INSPO"),
            checklistItems = emptyList(),
            imageUrl = INSPIRATION_WALL_IMAGE,
            codeSnippet = "",
            canvasX = 360L,
            canvasY = 320L,
            rotationDeg = 0L,
            dateLabel = "Oct 09, 2023"
        ),
        IdeaNote(
            id = "seed_done_6",
            userId = userId,
            title = "Client Presentation Deck",
            content = "Finalize slides 10-15. Add the new user flow diagrams.",
            noteType = "image",
            colorTheme = "pink",
            status = "completed",
            tags = listOf("CLIENT"),
            checklistItems = emptyList(),
            imageUrl = PRESENTATION_DECK_IMAGE,
            codeSnippet = "",
            canvasX = 660L,
            canvasY = 320L,
            rotationDeg = 0L,
            dateLabel = "Oct 08, 2023"
        ),
        IdeaNote(
            id = "seed_done_7",
            userId = userId,
            title = "Grocery List",
            content = "Weekly studio pantry restock.",
            noteType = "checklist",
            colorTheme = "yellow",
            status = "completed",
            tags = listOf("PERSONAL"),
            checklistItems = listOf(
                "Almond milk",
                "Avocados",
                "Sourdough bread",
                "Coffee beans"
            ),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 120L,
            canvasY = 580L,
            rotationDeg = 0L,
            dateLabel = "Oct 10, 2023"
        ),
        IdeaNote(
            id = "seed_done_8",
            userId = userId,
            title = "Design System Update",
            content = "Audit all button states. Ensure hover states have the correct shadow blur radius (30px). Update Figma library.",
            noteType = "text",
            colorTheme = "neutral",
            status = "completed",
            tags = listOf("DESIGN", "SYSTEM"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 420L,
            canvasY = 580L,
            rotationDeg = 0L,
            dateLabel = "Oct 08, 2023"
        ),
        IdeaNote(
            id = "seed_done_9",
            userId = userId,
            title = "Fix Login Bug",
            content = "Users reporting endless spinner on mobile safari. Need to patch ASAP.",
            noteType = "text",
            colorTheme = "coral",
            status = "completed",
            tags = listOf("URGENT", "DEV"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 720L,
            canvasY = 580L,
            rotationDeg = 0L,
            dateLabel = "Oct 08, 2023"
        ),

        // Archived Note
        IdeaNote(
            id = "seed_arch_1",
            userId = userId,
            title = "Brand Identity Tokens",
            content = "Schedule a brainstorming session for the new brand identity tokens and warm yellow accent scale.",
            noteType = "text",
            colorTheme = "green",
            status = "archived",
            tags = listOf("ARCHIVE", "BRAND"),
            checklistItems = emptyList(),
            imageUrl = "",
            codeSnippet = "",
            canvasX = 200L,
            canvasY = 200L,
            rotationDeg = 0L,
            dateLabel = "Oct 05, 2023"
        )
    )
}
