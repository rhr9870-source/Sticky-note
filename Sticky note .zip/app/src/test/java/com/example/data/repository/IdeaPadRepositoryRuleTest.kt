package com.example.data.repository

import com.example.base.FirestoreEmulatorTestBase
import com.example.data.model.IdeaNote
import com.example.data.model.UserPreferences
import com.google.firebase.firestore.FirebaseFirestoreException
import java.util.UUID
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class IdeaPadRepositoryRuleTest : FirestoreEmulatorTestBase() {

    @Test
    fun createNote_validPayload_createsAndReadsDocument() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = IdeaPadRepository(firestore, auth)
        val uniqueId = "note_${UUID.randomUUID().toString().replace("-", "").take(12)}"

        val note = IdeaNote(
            id = uniqueId,
            userId = uid,
            title = "Redesign Hero",
            content = "Needs softer gradients",
            noteType = "text",
            colorTheme = "yellow",
            status = "active",
            tags = listOf("Design", "Urgent")
        )

        val createResult = withTimeout(DEFAULT_TIMEOUT_MS) { repository.createNote(note) }
        assertTrue("Expected createNote to succeed", createResult.isSuccess)
        val createdId = createResult.getOrThrow()
        assertEquals(uniqueId, createdId)

        val fetched = withTimeout(DEFAULT_TIMEOUT_MS) { repository.getNoteById(createdId, uid).getOrThrow() }
        assertNotNull(fetched)
        assertEquals("Redesign Hero", fetched?.title)
    }

    @Test
    fun observeNotes_authenticatedOwner_emitsRealtimeUpdates() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = IdeaPadRepository(firestore, auth)
        val uniqueId = "note_${UUID.randomUUID().toString().replace("-", "").take(12)}"

        val note = IdeaNote(
            id = uniqueId,
            userId = uid,
            title = "Realtime Note",
            content = "Testing Flow emission",
            noteType = "text",
            colorTheme = "green",
            status = "active"
        )
        withTimeout(DEFAULT_TIMEOUT_MS) { repository.createNote(note).getOrThrow() }

        val emitted = withTimeout(FLOW_TIMEOUT_MS) {
            repository.observeNotes(uid).first { list -> list.any { it.id == uniqueId } }
        }
        assertTrue(emitted.any { it.id == uniqueId })
    }

    @Test
    fun updateAndPreferences_authenticatedOwner_succeeds() = runBlocking {
        val uid = signInTestUser(ALICE_EMAIL)
        val repository = IdeaPadRepository(firestore, auth)
        val uniqueId = "note_${UUID.randomUUID().toString().replace("-", "").take(12)}"

        val note = IdeaNote(
            id = uniqueId,
            userId = uid,
            title = "Initial Title",
            content = "Initial Content",
            status = "active"
        )
        withTimeout(DEFAULT_TIMEOUT_MS) { repository.createNote(note).getOrThrow() }

        val fetched = withTimeout(DEFAULT_TIMEOUT_MS) { repository.getNoteById(uniqueId, uid).getOrThrow()!! }
        val updateRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.updateNote(fetched.copy(status = "completed", canvasX = 320L))
        }
        assertTrue(updateRes.isSuccess)

        val prefsRes = withTimeout(DEFAULT_TIMEOUT_MS) {
            repository.savePreferences(
                UserPreferences(
                    userId = uid,
                    displayName = "Creative Thinker",
                    email = ALICE_EMAIL,
                    themeMode = "dark"
                )
            )
        }
        assertTrue(prefsRes.isSuccess)
    }

    @Test
    fun getNoteById_crossUserAccess_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        val aliceRepo = IdeaPadRepository(firestore, auth)
        val uniqueId = "note_${UUID.randomUUID().toString().replace("-", "").take(12)}"
        withTimeout(DEFAULT_TIMEOUT_MS) {
            aliceRepo.createNote(IdeaNote(id = uniqueId, userId = aliceUid, title = "Alice Secret")).getOrThrow()
        }

        signInTestUser(BOB_EMAIL)
        val bobRepo = IdeaPadRepository(firestore, auth)
        try {
            withTimeout(DEFAULT_TIMEOUT_MS) {
                bobRepo.getNoteById(uniqueId, aliceUid).getOrThrow()
            }
            fail("Expected FirebaseFirestoreException PERMISSION_DENIED for cross-user read")
        } catch (e: FirebaseFirestoreException) {
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, e.code)
        }
    }

    @Test
    fun observeNotes_unauthenticatedUser_failsWithPermissionDenied() = runBlocking {
        val aliceUid = signInTestUser(ALICE_EMAIL)
        auth.signOut()
        val repository = IdeaPadRepository(firestore, auth)

        try {
            withTimeout(FLOW_TIMEOUT_MS) {
                repository.observeNotes(aliceUid).first()
            }
            fail("Expected FirebaseFirestoreException PERMISSION_DENIED when unauthenticated")
        } catch (e: Throwable) {
            val fse = generateSequence(e) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
            assertNotNull("Expected FirebaseFirestoreException in cause chain: ${e.stackTraceToString()}", fse)
            assertEquals(FirebaseFirestoreException.Code.PERMISSION_DENIED, fse?.code)
        }
    }

    private companion object {
        const val ALICE_EMAIL = "alice@ideapad.test"
        const val BOB_EMAIL = "bob@ideapad.test"
        const val DEFAULT_TIMEOUT_MS = 5000L
        const val FLOW_TIMEOUT_MS = 4000L
    }
}
