const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
const PROJECT_ID = process.env.GCP_PROJECT || "demo-no-project";
const ALICE_UID = "alice_123";
const BOB_UID = "bob_456";

const [emulatorHost, emulatorPortStr] = (process.env.FIRESTORE_EMULATOR_HOST || "127.0.0.1:8085").split(":");
const emulatorPort = parseInt(emulatorPortStr, 10);

function validNotePayload(userId, now) {
  return {
    userId,
    title: "Q3 Marketing Brainstorm",
    content: "Draft initial concepts for the fall campaign.",
    noteType: "checklist",
    colorTheme: "yellow",
    status: "active",
    tags: ["WORK", "PLANNING"],
    checklistItems: ["Finalize moodboard", "Draft social media copy"],
    imageUrl: "",
    codeSnippet: "",
    canvasX: 120,
    canvasY: 80,
    rotationDeg: -1,
    dateLabel: "Oct 12, 2023",
    createdAt: now,
    updatedAt: now,
  };
}

function validPrefsPayload(userId, now) {
  return {
    userId,
    displayName: "Creative Thinker",
    email: "hello@ideapad.app",
    themeMode: "light",
    reduceMotion: false,
    defaultNoteColor: "yellow",
    defaultTypography: "bricolage",
    canvasGridEnabled: true,
    snapToGrid: true,
    gridDensity: 2,
    lastSyncedLabel: "Just now",
    createdAt: now,
    updatedAt: now,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("1. Unauthenticated user cannot read or list notes", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("notes").get());
});

test("2. Authenticated owner can create and read a valid note", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertSucceeds(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("notes")
      .doc("note_1")
      .set(validNotePayload(ALICE_UID, now))
  );
  await assertSucceeds(
    aliceDb.collection("users").doc(ALICE_UID).collection("notes").doc("note_1").get()
  );
});

test("3. Cross-user access: Bob cannot read or update Alice's note", async () => {
  const now = new Date();
  await testEnv.withSecurityRulesDisabled(async (context) => {
    await context
      .firestore()
      .collection("users")
      .doc(ALICE_UID)
      .collection("notes")
      .doc("note_1")
      .set(validNotePayload(ALICE_UID, now));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("notes").doc("note_1").get()
  );
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("notes").get()
  );
});

test("4. Identity spoofing: Alice cannot create a note with Bob's userId", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("notes")
      .doc("note_spoof")
      .set(validNotePayload(BOB_UID, now))
  );
});

test("5. Shadow update / Ghost field injection is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("notes")
      .doc("note_ghost")
      .set({ ...validNotePayload(ALICE_UID, now), isVerified: true })
  );
});

test("6. Invalid enum in status or colorTheme is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const now = new Date();
  await assertFails(
    aliceDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("notes")
      .doc("note_bad_enum")
      .set({ ...validNotePayload(ALICE_UID, now), status: "invalid_status" })
  );
});

test("7. Owner can update status and position of their note, but cannot mutate createdAt", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const createdTime = new Date(Date.now() - 5000);
  const ref = aliceDb.collection("users").doc(ALICE_UID).collection("notes").doc("note_1");
  await assertSucceeds(ref.set(validNotePayload(ALICE_UID, createdTime)));

  await assertSucceeds(
    ref.update({
      status: "completed",
      canvasX: 240,
      updatedAt: new Date(),
    })
  );

  await assertFails(
    ref.update({
      createdAt: new Date(),
      updatedAt: new Date(),
    })
  );
});

test("8. Preferences: Owner can create/update preferences, cross-user is rejected", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const now = new Date();
  const prefRef = aliceDb
    .collection("users")
    .doc(ALICE_UID)
    .collection("settings")
    .doc("preferences");

  await assertSucceeds(prefRef.set(validPrefsPayload(ALICE_UID, now)));
  await assertFails(
    bobDb.collection("users").doc(ALICE_UID).collection("settings").doc("preferences").get()
  );
});
